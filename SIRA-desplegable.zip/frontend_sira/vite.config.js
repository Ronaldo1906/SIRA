import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// En desarrollo el frontend corre en 5173 y reenvía /api y /uploads al backend
// (8000). En producción el build se sirve desde el propio backend, así que las
// rutas relativas funcionan igual sin configurar ninguna URL absoluta.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8000', changeOrigin: true },
      '/uploads': { target: 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  preview: {
    host: true,
    port: 4173,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8000', changeOrigin: true },
      '/uploads': { target: 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
