import axios from 'axios';

// En producción el frontend se sirve desde el mismo origen que la API, por eso
// la base es relativa ("/api"). Si se necesita apuntar a otro servidor, basta
// con definir VITE_API_URL al compilar.
const baseURL = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/, '');

const API = axios.create({
  baseURL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

API.interceptors.request.use((config) => {
  const guardado = localStorage.getItem('sira_usuario');
  if (guardado) {
    try {
      const { token } = JSON.parse(guardado);
      if (token) config.headers.Authorization = `Bearer ${token}`;
    } catch {
      /* sesión corrupta: se ignora */
    }
  }
  return config;
});

API.interceptors.response.use(
  (respuesta) => respuesta,
  (error) => {
    const detalle = error.response?.data?.detail;
    const mensaje =
      typeof detalle === 'string'
        ? detalle
        : detalle
        ? JSON.stringify(detalle)
        : error.message === 'Network Error'
        ? 'No se pudo conectar con el servidor. Verifica que el backend esté activo.'
        : error.message;
    return Promise.reject(new Error(mensaje));
  }
);

export const getActividadesDB = async () => {
  try {
    const { data } = await API.get('/actividades');
    return data;
  } catch (error) {
    console.error('Error cargando actividades desde la BD:', error.message);
    return [];
  }
};

export const urlDescarga = (idRepositorio) => `${baseURL}/materiales/${idRepositorio}/descargar`;

export default API;
