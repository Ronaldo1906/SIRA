import API from './api';

/**
 * Inicia sesión contra POST /api/login.
 * @param {{username: string, password: string}} credentials
 * @returns {Promise<{token: string, usuario: string, id_usuario: number, rol: string}>}
 */
export const login = async (credentials) => {
  const { data } = await API.post('/login', {
    username: credentials.username?.trim(),
    password: credentials.password,
  });
  return data;
};

export const logout = () => {
  localStorage.removeItem('sira_usuario');
  localStorage.removeItem('id_usuario');
  localStorage.removeItem('rol');
  localStorage.removeItem('usuario');
  localStorage.removeItem('token');
};
