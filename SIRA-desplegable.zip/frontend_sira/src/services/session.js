/** Utilidades de sesión guardada en localStorage. */

export const guardarSesion = (datos) => {
  localStorage.setItem('sira_usuario', JSON.stringify(datos));
  localStorage.setItem('id_usuario', String(datos.id_usuario));
  localStorage.setItem('rol', datos.rol || 'USUARIO');
  localStorage.setItem('usuario', datos.usuario || '');
  localStorage.setItem('token', datos.token || '');
};

export const limpiarSesion = () => {
  ['sira_usuario', 'id_usuario', 'rol', 'usuario', 'token'].forEach((k) => localStorage.removeItem(k));
};

export const getSesion = () => {
  let datos = null;
  try {
    datos = JSON.parse(localStorage.getItem('sira_usuario') || 'null');
  } catch {
    datos = null;
  }
  const id = Number(datos?.id_usuario || localStorage.getItem('id_usuario') || 0);
  return {
    id_usuario: Number.isFinite(id) && id > 0 ? id : null,
    rol: datos?.rol || localStorage.getItem('rol') || 'USUARIO',
    nombre: datos?.usuario || localStorage.getItem('usuario') || '',
    token: datos?.token || localStorage.getItem('token') || '',
  };
};

export const estaAutenticado = () => Boolean(getSesion().id_usuario);
