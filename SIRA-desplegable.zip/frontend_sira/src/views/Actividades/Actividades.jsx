import React, { useCallback, useEffect, useRef, useState } from 'react';
import PageShell from '../../components/layout/PageShell';
import API from '../../services/api';
import { getSesion } from '../../services/session';

const fmtFecha = (valor) => {
  if (!valor) return '—';
  const d = new Date(valor);
  if (Number.isNaN(d.getTime())) return String(valor);
  return d.toLocaleString('es-CO', { dateStyle: 'medium', timeStyle: 'short' });
};

const estadoInfo = (act) => {
  if (act.estado === 'EVALUADO') return { texto: `Evaluado · ${act.nota ?? '—'}`, color: '#15803d', bg: '#dcfce7' };
  if (act.estado === 'ENVIADO') return { texto: 'Enviado · en revisión', color: '#1d4ed8', bg: '#dbeafe' };
  if (act.estado === 'CORREGIR') return { texto: 'Requiere corrección', color: '#b45309', bg: '#fef3c7' };
  return { texto: 'Pendiente de entrega', color: '#475569', bg: '#e2e8f0' };
};

export default function Actividades() {
  const sesion = getSesion();
  const esInstructor = sesion.rol === 'INSTRUCTOR';

  const [actividades, setActividades] = useState([]);
  const [fichas, setFichas] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [subiendo, setSubiendo] = useState(null);
  const [form, setForm] = useState({
    titulo: '',
    descripcion: '',
    tipo_actividad: 'Taller',
    fecha_vencimiento: '',
    id_ficha: '',
  });
  const inputsArchivo = useRef({});

  const cargar = useCallback(async () => {
    if (!sesion.id_usuario) return;
    setCargando(true);
    setError('');
    try {
      if (esInstructor) {
        const [acts, fichasResp] = await Promise.all([
          API.get(`/instructores/${sesion.id_usuario}/actividades-avance`),
          API.get(`/fichas?id_instructor=${sesion.id_usuario}`),
        ]);
        setActividades(acts.data);
        setFichas(fichasResp.data);
        setForm((f) => ({ ...f, id_ficha: f.id_ficha || fichasResp.data[0]?.id_ficha || '' }));
      } else {
        const { data } = await API.get(`/aprendices/${sesion.id_usuario}/actividades`);
        setActividades(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }, [esInstructor, sesion.id_usuario]);

  useEffect(() => {
    cargar();
  }, [cargar]);

  const crearActividad = async (e) => {
    e.preventDefault();
    setError('');
    setAviso('');
    if (!form.id_ficha) {
      setError('Selecciona una ficha para la actividad');
      return;
    }
    try {
      await API.post('/actividades', {
        titulo: form.titulo,
        descripcion: form.descripcion || null,
        fecha_vencimiento: form.fecha_vencimiento.length === 16 ? `${form.fecha_vencimiento}:00` : form.fecha_vencimiento,
        tipo_actividad: form.tipo_actividad,
        id_instructor: sesion.id_usuario,
        id_ficha: Number(form.id_ficha),
      });
      setAviso('Actividad creada correctamente');
      setForm({ titulo: '', descripcion: '', tipo_actividad: 'Taller', fecha_vencimiento: '', id_ficha: form.id_ficha });
      cargar();
    } catch (err) {
      setError(err.message);
    }
  };

  const eliminarActividad = async (id) => {
    if (!window.confirm('¿Deseas eliminar esta actividad y todas sus entregas?')) return;
    try {
      await API.delete(`/actividades/${id}`);
      setAviso('Actividad eliminada');
      cargar();
    } catch (err) {
      setError(err.message);
    }
  };

  const subirEntrega = async (idActividad, archivo) => {
    if (!archivo) return;
    setError('');
    setAviso('');
    setSubiendo(idActividad);
    try {
      const datos = new FormData();
      datos.append('id_actividad', idActividad);
      datos.append('id_aprendiz', sesion.id_usuario);
      datos.append('archivo', archivo);
      await API.post('/entregas/upload', datos, { headers: { 'Content-Type': 'multipart/form-data' } });
      setAviso(`Entrega "${archivo.name}" registrada correctamente`);
      cargar();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubiendo(null);
      if (inputsArchivo.current[idActividad]) inputsArchivo.current[idActividad].value = '';
    }
  };

  return (
    <PageShell
      title={esInstructor ? '📝 Gestión de Actividades' : '📝 Mis Actividades'}
      subtitle={
        esInstructor
          ? 'Crea actividades para tus fichas y revisa el avance de las entregas'
          : 'Consulta tus actividades, sube tus evidencias y revisa la retroalimentación'
      }
    >
      {error && <div style={styles.alertError}>{error}</div>}
      {aviso && <div style={styles.alertOk}>{aviso}</div>}

      {esInstructor && (
        <form onSubmit={crearActividad} style={styles.formCard}>
          <h3 style={styles.formTitle}>Nueva actividad</h3>
          <div style={styles.formGrid}>
            <input
              style={{ ...styles.input, gridColumn: 'span 2' }}
              placeholder="Título de la actividad"
              value={form.titulo}
              onChange={(e) => setForm({ ...form, titulo: e.target.value })}
              maxLength={150}
              required
            />
            <select
              style={styles.input}
              value={form.tipo_actividad}
              onChange={(e) => setForm({ ...form, tipo_actividad: e.target.value })}
            >
              {['Taller', 'Quiz', 'Proyecto', 'Evaluación', 'Foro'].map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <select
              style={styles.input}
              value={form.id_ficha}
              onChange={(e) => setForm({ ...form, id_ficha: e.target.value })}
              required
            >
              <option value="">Selecciona una ficha</option>
              {fichas.map((f) => (
                <option key={f.id_ficha} value={f.id_ficha}>
                  {f.numero_ficha} · {f.nombre_programa}
                </option>
              ))}
            </select>
            <input
              style={styles.input}
              type="datetime-local"
              value={form.fecha_vencimiento}
              onChange={(e) => setForm({ ...form, fecha_vencimiento: e.target.value })}
              required
            />
          </div>
          <textarea
            style={{ ...styles.input, ...styles.textarea }}
            placeholder="Descripción (opcional)"
            value={form.descripcion}
            onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
            rows={2}
          />
          <button type="submit" style={styles.btnPrimario}>Crear actividad</button>
        </form>
      )}

      {cargando ? (
        <p style={styles.info}>Cargando actividades desde la base de datos...</p>
      ) : actividades.length === 0 ? (
        <p style={styles.info}>No hay actividades registradas todavía.</p>
      ) : (
        <div style={styles.lista}>
          {actividades.map((act) => {
            const vencida = new Date(act.fecha_vencimiento) < new Date();
            const info = estadoInfo(act);
            const total = Number(act.total_aprendices || 0);
            const recibidas = Number(act.entregas_recibidas || 0);
            return (
              <article key={act.id_actividad} style={styles.item}>
                <div style={styles.itemHead}>
                  <div>
                    <h3 style={styles.itemTitle}>{act.titulo}</h3>
                    <p style={styles.itemMeta}>
                      {act.tipo_actividad || 'Actividad'} · Ficha {act.numero_ficha} · Vence: {fmtFecha(act.fecha_vencimiento)}
                      {vencida && <span style={styles.vencida}> · vencida</span>}
                    </p>
                    {act.descripcion && <p style={styles.itemDesc}>{act.descripcion}</p>}
                  </div>
                  {!esInstructor && (
                    <span style={{ ...styles.badge, color: info.color, background: info.bg }}>{info.texto}</span>
                  )}
                  {esInstructor && (
                    <span style={{ ...styles.badge, color: '#4c1d95', background: '#ede9fe' }}>
                      {recibidas}/{total} entregas
                    </span>
                  )}
                </div>

                {esInstructor && (
                  <>
                    <div style={styles.progressTrack}>
                      <div
                        style={{
                          ...styles.progressBar,
                          width: `${total ? Math.min(100, (recibidas / total) * 100) : 0}%`,
                        }}
                      />
                    </div>
                    <div style={styles.itemActions}>
                      <button style={styles.btnEliminar} onClick={() => eliminarActividad(act.id_actividad)}>
                        🗑️ Eliminar
                      </button>
                    </div>
                  </>
                )}

                {!esInstructor && (
                  <div style={styles.itemActions}>
                    {act.retroalimentacion && (
                      <p style={styles.retro}>💬 {act.retroalimentacion}</p>
                    )}
                    {act.archivo_entrega && (
                      <p style={styles.archivo}>📎 {act.archivo_entrega}</p>
                    )}
                    <label style={{ ...styles.btnEntregar, opacity: vencida ? 0.55 : 1 }}>
                      {subiendo === act.id_actividad
                        ? 'Subiendo...'
                        : vencida
                        ? 'Plazo vencido'
                        : act.id_entrega
                        ? 'Reemplazar entrega'
                        : 'Adjuntar entrega'}
                      <input
                        type="file"
                        style={{ display: 'none' }}
                        disabled={vencida || subiendo === act.id_actividad}
                        ref={(el) => {
                          inputsArchivo.current[act.id_actividad] = el;
                        }}
                        onChange={(e) => subirEntrega(act.id_actividad, e.target.files?.[0])}
                      />
                    </label>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </PageShell>
  );
}

const styles = {
  formCard: {
    background: 'rgba(255,255,255,0.96)',
    padding: '22px',
    borderRadius: '16px',
    marginBottom: '22px',
    boxShadow: '0 10px 24px rgba(0,0,0,0.16)',
  },
  formTitle: { margin: '0 0 14px', color: '#1e293b', fontSize: '17px' },
  formGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '12px', marginBottom: '12px' },
  input: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '9px',
    border: '1px solid #cbd5e1',
    fontSize: '14px',
    boxSizing: 'border-box',
    background: 'white',
    color: '#0f172a',
  },
  textarea: { resize: 'vertical', marginBottom: '12px', fontFamily: 'inherit' },
  btnPrimario: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '11px 22px',
    borderRadius: '9px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '14px',
  },
  lista: { display: 'flex', flexDirection: 'column', gap: '16px' },
  item: {
    background: 'rgba(255,255,255,0.97)',
    borderRadius: '16px',
    padding: '20px 22px',
    boxShadow: '0 10px 24px rgba(0,0,0,0.16)',
  },
  itemHead: { display: 'flex', justifyContent: 'space-between', gap: '16px', alignItems: 'flex-start', flexWrap: 'wrap' },
  itemTitle: { margin: '0 0 4px', color: '#1e293b', fontSize: '18px' },
  itemMeta: { margin: 0, color: '#64748b', fontSize: '13px' },
  itemDesc: { margin: '8px 0 0', color: '#475569', fontSize: '14px' },
  vencida: { color: '#b91c1c', fontWeight: '700' },
  badge: { padding: '6px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '700', whiteSpace: 'nowrap' },
  progressTrack: { height: '7px', background: '#e2e8f0', borderRadius: '10px', marginTop: '14px', overflow: 'hidden' },
  progressBar: { height: '100%', background: 'linear-gradient(90deg, #667eea, #764ba2)', borderRadius: '10px' },
  itemActions: { display: 'flex', alignItems: 'center', gap: '12px', marginTop: '14px', flexWrap: 'wrap' },
  btnEliminar: {
    background: '#fee2e2',
    color: '#b91c1c',
    border: '1px solid #fecaca',
    padding: '8px 14px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '13px',
  },
  btnEntregar: {
    background: '#15803d',
    color: 'white',
    padding: '9px 18px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '13px',
    display: 'inline-block',
  },
  retro: { margin: 0, fontSize: '13px', color: '#334155', background: '#f1f5f9', padding: '8px 12px', borderRadius: '8px' },
  archivo: { margin: 0, fontSize: '13px', color: '#15803d', fontWeight: '600' },
  info: { color: 'white', background: 'rgba(15,23,42,0.55)', padding: '16px', borderRadius: '12px' },
  alertError: { background: '#fee2e2', color: '#b91c1c', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
  alertOk: { background: '#dcfce7', color: '#15803d', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
};
