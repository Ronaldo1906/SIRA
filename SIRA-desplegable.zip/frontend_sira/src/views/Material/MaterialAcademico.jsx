import React, { useCallback, useEffect, useState } from 'react';
import PageShell from '../../components/layout/PageShell';
import API, { urlDescarga } from '../../services/api';
import { getSesion } from '../../services/session';

const fmtFecha = (valor) => {
  if (!valor) return '';
  const d = new Date(valor);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString('es-CO', { dateStyle: 'medium' });
};

export default function MaterialAcademico() {
  const sesion = getSesion();
  const esInstructor = sesion.rol === 'INSTRUCTOR';

  const [materiales, setMateriales] = useState([]);
  const [actividades, setActividades] = useState([]);
  const [idActividad, setIdActividad] = useState('');
  const [archivo, setArchivo] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [subiendo, setSubiendo] = useState(false);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [filtro, setFiltro] = useState('');

  const cargar = useCallback(async () => {
    if (!sesion.id_usuario) return;
    setCargando(true);
    setError('');
    try {
      const { data } = await API.get('/materiales');
      setMateriales(data);
      if (esInstructor) {
        const acts = await API.get(`/instructores/${sesion.id_usuario}/actividades-avance`);
        setActividades(acts.data);
        setIdActividad((prev) => prev || acts.data[0]?.id_actividad || '');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }, [esInstructor, sesion.id_usuario]);

  useEffect(() => {
    cargar();
  }, [cargar]);

  const subir = async (e) => {
    e.preventDefault();
    setError('');
    setAviso('');
    if (!archivo || !idActividad) {
      setError('Selecciona una actividad y un archivo');
      return;
    }
    setSubiendo(true);
    try {
      const datos = new FormData();
      datos.append('id_actividad', idActividad);
      datos.append('id_instructor', sesion.id_usuario);
      datos.append('archivo', archivo);
      await API.post('/materiales/upload', datos, { headers: { 'Content-Type': 'multipart/form-data' } });
      setAviso(`Recurso "${archivo.name}" subido correctamente`);
      setArchivo(null);
      e.target.reset();
      cargar();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubiendo(false);
    }
  };

  const eliminar = async (id) => {
    if (!window.confirm('¿Deseas eliminar este recurso del material académico?')) return;
    try {
      await API.delete(`/materiales/${id}`);
      setAviso('Recurso eliminado');
      cargar();
    } catch (err) {
      setError(err.message);
    }
  };

  const visibles = filtro
    ? materiales.filter((m) => String(m.id_actividad) === String(filtro))
    : materiales;

  return (
    <PageShell
      title="📚 Material Académico"
      subtitle={esInstructor ? 'Comparte guías y recursos con tus aprendices' : 'Descarga los recursos publicados por tus instructores'}
    >
      {error && <div style={styles.alertError}>{error}</div>}
      {aviso && <div style={styles.alertOk}>{aviso}</div>}

      {esInstructor && (
        <form onSubmit={subir} style={styles.formCard}>
          <h3 style={styles.formTitle}>Subir nuevo recurso</h3>
          <div style={styles.formGrid}>
            <select style={styles.input} value={idActividad} onChange={(e) => setIdActividad(e.target.value)} required>
              <option value="">Selecciona una actividad</option>
              {actividades.map((a) => (
                <option key={a.id_actividad} value={a.id_actividad}>
                  {a.titulo} (ficha {a.numero_ficha})
                </option>
              ))}
            </select>
            <input
              style={styles.fileInput}
              type="file"
              onChange={(e) => setArchivo(e.target.files?.[0] || null)}
              required
            />
            <button type="submit" style={styles.btnPrimario} disabled={subiendo}>
              {subiendo ? 'Subiendo...' : 'Subir recurso'}
            </button>
          </div>
          {actividades.length === 0 && (
            <p style={styles.hint}>Primero crea una actividad para poder adjuntar material.</p>
          )}
        </form>
      )}

      <div style={styles.toolbar}>
        <select style={{ ...styles.input, maxWidth: '340px' }} value={filtro} onChange={(e) => setFiltro(e.target.value)}>
          <option value="">Todas las actividades</option>
          {[...new Map(materiales.map((m) => [m.id_actividad, m.actividad])).entries()].map(([id, titulo]) => (
            <option key={id} value={id}>{titulo || 'Sin actividad'}</option>
          ))}
        </select>
        <span style={styles.contador}>{visibles.length} recurso(s)</span>
      </div>

      {cargando ? (
        <p style={styles.info}>Cargando material desde la base de datos...</p>
      ) : visibles.length === 0 ? (
        <p style={styles.info}>Todavía no hay material publicado.</p>
      ) : (
        <div style={styles.grid}>
          {visibles.map((m) => (
            <div key={m.id_repositorio} style={styles.card}>
              <div style={styles.fileIcon}>{(m.tipo_formato || 'doc').toUpperCase()}</div>
              <h3 style={styles.cardTitle}>{m.nombre_archivo}</h3>
              <p style={styles.cardMeta}>{m.actividad || 'Sin actividad'}</p>
              <p style={styles.cardSub}>
                {m.instructor || 'Instructor'} · {m.tamanio ? `${m.tamanio} KB` : ''} {fmtFecha(m.fecha_subida)}
              </p>
              <div style={styles.actions}>
                <a style={styles.btnDescarga} href={urlDescarga(m.id_repositorio)} target="_blank" rel="noreferrer">
                  Descargar
                </a>
                {esInstructor && (
                  <button style={styles.btnEliminar} onClick={() => eliminar(m.id_repositorio)} title="Eliminar recurso">
                    🗑️
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}

const styles = {
  formCard: {
    background: 'rgba(255,255,255,0.96)',
    padding: '22px',
    borderRadius: '16px',
    marginBottom: '20px',
    boxShadow: '0 10px 24px rgba(0,0,0,0.16)',
  },
  formTitle: { margin: '0 0 14px', color: '#1e293b', fontSize: '17px' },
  formGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '12px', alignItems: 'center' },
  input: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '9px',
    border: '1px solid #cbd5e1',
    fontSize: '14px',
    background: 'white',
    color: '#0f172a',
    boxSizing: 'border-box',
  },
  fileInput: { fontSize: '13px', color: '#334155' },
  btnPrimario: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '11px 20px',
    borderRadius: '9px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '14px',
  },
  hint: { color: '#b45309', fontSize: '13px', margin: '10px 0 0' },
  toolbar: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' },
  contador: { color: 'white', fontSize: '13px', fontWeight: '600' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '18px' },
  card: {
    background: 'rgba(255,255,255,0.97)',
    padding: '22px',
    borderRadius: '16px',
    textAlign: 'center',
    boxShadow: '0 10px 24px rgba(0,0,0,0.16)',
  },
  fileIcon: {
    width: '54px',
    height: '54px',
    margin: '0 auto 12px',
    borderRadius: '14px',
    background: 'linear-gradient(135deg, #667eea, #764ba2)',
    color: 'white',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: '800',
    fontSize: '12px',
  },
  cardTitle: { margin: '0 0 6px', fontSize: '15px', color: '#1e293b', wordBreak: 'break-word' },
  cardMeta: { margin: 0, fontSize: '13px', color: '#4c51bf', fontWeight: '600' },
  cardSub: { margin: '6px 0 14px', fontSize: '12px', color: '#64748b' },
  actions: { display: 'flex', justifyContent: 'center', gap: '10px', alignItems: 'center' },
  btnDescarga: {
    background: '#4c51bf',
    color: 'white',
    padding: '9px 18px',
    borderRadius: '8px',
    textDecoration: 'none',
    fontWeight: '700',
    fontSize: '13px',
  },
  btnEliminar: {
    background: '#fee2e2',
    color: '#b91c1c',
    border: '1px solid #fecaca',
    padding: '9px 12px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '13px',
  },
  info: { color: 'white', background: 'rgba(15,23,42,0.55)', padding: '16px', borderRadius: '12px' },
  alertError: { background: '#fee2e2', color: '#b91c1c', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
  alertOk: { background: '#dcfce7', color: '#15803d', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
};
