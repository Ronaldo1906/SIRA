import React, { useEffect, useState } from 'react';
import PageShell from '../../components/layout/PageShell';
import API from '../../services/api';
import { getSesion } from '../../services/session';

export default function Perfil() {
  const sesion = getSesion();
  const [perfil, setPerfil] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [clave, setClave] = useState({ actual: '', nueva: '', repetir: '' });
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    if (!sesion.id_usuario) return;
    (async () => {
      try {
        const { data } = await API.get(`/usuarios/${sesion.id_usuario}/perfil`);
        setPerfil(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setCargando(false);
      }
    })();
  }, [sesion.id_usuario]);

  const cambiarClave = async (e) => {
    e.preventDefault();
    setError('');
    setAviso('');
    if (clave.nueva !== clave.repetir) {
      setError('La nueva contraseña y su confirmación no coinciden');
      return;
    }
    setGuardando(true);
    try {
      await API.put(`/usuarios/${sesion.id_usuario}/password`, {
        actual: clave.actual,
        nueva: clave.nueva,
      });
      setAviso('Contraseña actualizada correctamente');
      setClave({ actual: '', nueva: '', repetir: '' });
    } catch (err) {
      setError(err.message);
    } finally {
      setGuardando(false);
    }
  };

  return (
    <PageShell title="👤 Perfil del Usuario" subtitle="Información personal registrada en la base de datos">
      {error && <div style={styles.alertError}>{error}</div>}
      {aviso && <div style={styles.alertOk}>{aviso}</div>}

      {cargando ? (
        <p style={styles.info}>Cargando información del servidor...</p>
      ) : !perfil ? (
        <p style={styles.info}>No se pudo obtener la información del perfil.</p>
      ) : (
        <div style={styles.grid}>
          <section style={styles.card}>
            <h2 style={styles.title}>Datos personales</h2>
            <div style={styles.infoGrid}>
              <Field label="Nombres y apellidos" value={`${perfil.nombres} ${perfil.apellidos}`} />
              <Field label="Documento" value={perfil.num_documento} />
              <Field label="Correo electrónico" value={perfil.email} />
              <Field label="Rol asignado" value={perfil.rol} badge />
              {perfil.rol === 'APRENDIZ' && (
                <>
                  <Field label="Ficha" value={perfil.numero_ficha || 'Sin ficha'} />
                  <Field label="Programa" value={perfil.nombre_programa || '—'} />
                  <Field label="Teléfono" value={perfil.tel_aprendiz || 'No registrado'} />
                </>
              )}
              {perfil.rol === 'INSTRUCTOR' && (
                <>
                  <Field label="Acreditación" value={perfil.acred_lic || 'No registrada'} />
                  <Field label="Teléfono" value={perfil.tel_instructor || 'No registrado'} />
                </>
              )}
              <Field label="Fecha de registro" value={perfil.fecha_registro ? new Date(perfil.fecha_registro).toLocaleDateString('es-CO') : '—'} />
            </div>
          </section>

          <section style={styles.card}>
            <h2 style={styles.title}>Cambiar contraseña</h2>
            <form onSubmit={cambiarClave} style={styles.form}>
              <input
                style={styles.input}
                type="password"
                placeholder="Contraseña actual"
                value={clave.actual}
                onChange={(e) => setClave({ ...clave, actual: e.target.value })}
                autoComplete="current-password"
                required
              />
              <input
                style={styles.input}
                type="password"
                placeholder="Nueva contraseña (mínimo 4 caracteres)"
                value={clave.nueva}
                onChange={(e) => setClave({ ...clave, nueva: e.target.value })}
                autoComplete="new-password"
                minLength={4}
                required
              />
              <input
                style={styles.input}
                type="password"
                placeholder="Repite la nueva contraseña"
                value={clave.repetir}
                onChange={(e) => setClave({ ...clave, repetir: e.target.value })}
                autoComplete="new-password"
                minLength={4}
                required
              />
              <button type="submit" style={styles.btnPrimario} disabled={guardando}>
                {guardando ? 'Guardando...' : 'Actualizar contraseña'}
              </button>
            </form>
          </section>
        </div>
      )}
    </PageShell>
  );
}

function Field({ label, value, badge }) {
  return (
    <div style={styles.infoGroup}>
      <span style={styles.label}>{label}</span>
      {badge ? <span style={styles.badge}>{value}</span> : <span style={styles.val}>{value}</span>}
    </div>
  );
}

const styles = {
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px' },
  card: { background: 'rgba(255,255,255,0.97)', padding: '28px', borderRadius: '18px', boxShadow: '0 10px 24px rgba(0,0,0,0.16)' },
  title: {
    color: '#1e293b',
    fontSize: '19px',
    fontWeight: '800',
    marginTop: 0,
    marginBottom: '20px',
    borderBottom: '2px solid #e2e8f0',
    paddingBottom: '10px',
  },
  infoGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '18px' },
  infoGroup: { display: 'flex', flexDirection: 'column', gap: '5px' },
  label: { color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.5px' },
  val: { fontSize: '15px', color: '#0f172a', fontWeight: '600', wordBreak: 'break-word' },
  badge: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    padding: '6px 14px',
    borderRadius: '20px',
    fontSize: '12px',
    width: 'fit-content',
    fontWeight: '700',
  },
  form: { display: 'flex', flexDirection: 'column', gap: '12px' },
  input: {
    padding: '11px 13px',
    borderRadius: '9px',
    border: '1px solid #cbd5e1',
    fontSize: '14px',
    background: 'white',
    color: '#0f172a',
  },
  btnPrimario: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '12px',
    borderRadius: '9px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '14px',
  },
  info: { color: 'white', background: 'rgba(15,23,42,0.55)', padding: '16px', borderRadius: '12px' },
  alertError: { background: '#fee2e2', color: '#b91c1c', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
  alertOk: { background: '#dcfce7', color: '#15803d', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
};
