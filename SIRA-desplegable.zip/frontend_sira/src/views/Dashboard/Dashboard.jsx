import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import fondoAuditorio from '../../assets/auditorio.jpg';
import API from '../../services/api';
import { getSesion } from '../../services/session';

export default function Dashboard() {
  const navigate = useNavigate();
  const sesion = getSesion();
  const idUsuario = sesion.id_usuario;
  const [perfil, setPerfil] = useState(null);
  const [resumen, setResumen] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!idUsuario) {
      navigate('/login', { replace: true });
      return;
    }
    let activo = true;
    (async () => {
      try {
        const { data } = await API.get(`/usuarios/${idUsuario}/perfil`);
        if (!activo) return;
        setPerfil(data);
        if (data.rol === 'APRENDIZ') {
          const rep = await API.get(`/reportes/aprendiz/${idUsuario}`);
          if (activo) setResumen(rep.data);
        } else if (data.rol === 'INSTRUCTOR') {
          const [acts, fichas] = await Promise.all([
            API.get(`/instructores/${idUsuario}/actividades-avance`),
            API.get(`/fichas?id_instructor=${idUsuario}`),
          ]);
          if (activo) {
            setResumen({
              total_actividades: acts.data.length,
              total_entregas: acts.data.reduce((acc, a) => acc + Number(a.entregas_recibidas || 0), 0),
              total_fichas: fichas.data.length,
            });
          }
        }
      } catch (err) {
        if (activo) setError(err.message);
      }
    })();
    return () => {
      activo = false;
    };
  }, [idUsuario, navigate]);

  const nombreCompleto = perfil ? `${perfil.nombres} ${perfil.apellidos}` : 'Cargando...';
  const iniciales = perfil
    ? `${perfil.nombres?.[0] || ''}${perfil.apellidos?.[0] || ''}`.toUpperCase()
    : '..';
  const rol = perfil?.rol || sesion.rol;

  const cerrarSesion = () => {
    if (window.confirm('¿Seguro que quieres cerrar sesión?')) {
      ['sira_usuario', 'id_usuario', 'rol', 'usuario', 'token'].forEach((k) => localStorage.removeItem(k));
      navigate('/login', { replace: true });
    }
  };

  const menuItems = [
    { icon: '👤', title: 'Perfil', desc: 'Consulta tu información personal y cambia tu contraseña', path: '/perfil' },
    { icon: '📝', title: 'Actividades', desc: 'Revisa tareas, fechas de entrega y sube tus evidencias', path: '/actividades' },
    { icon: '📚', title: 'Material Académico', desc: 'Descarga guías y recursos, o compártelos si eres instructor', path: '/material' },
    { icon: '📊', title: 'Reportes', desc: 'Consulta calificaciones, entregas y progreso académico', path: '/reportes' },
  ];

  return (
    <div style={{ ...styles.body, backgroundImage: `url(${fondoAuditorio})` }}>
      <div style={styles.overlay}>
        <nav style={styles.navbar}>
          <h1 style={styles.logo}>🎓 Sistema Académico</h1>
          <div style={styles.userInfo}>
            <span>{nombreCompleto}</span>
            <div style={styles.avatar}>{iniciales}</div>
            <button style={styles.btnLogout} onClick={cerrarSesion}>Salir</button>
          </div>
        </nav>

        <div style={styles.container}>
          <div style={styles.welcome}>
            <h2>Bienvenido, {rol === 'INSTRUCTOR' ? 'Instructor' : rol === 'APRENDIZ' ? 'Aprendiz' : 'Usuario'}</h2>
            <p>{perfil?.nombre_programa || perfil?.email || 'Selecciona una opción para continuar'}</p>
          </div>

          {error && <div style={styles.error}>{error}</div>}

          {resumen && (
            <div style={styles.stats}>
              {rol === 'APRENDIZ' ? (
                <>
                  <Stat label="Entregas" value={resumen.total_entregas ?? 0} />
                  <Stat label="Evaluadas" value={resumen.evaluadas ?? 0} />
                  <Stat label="Promedio" value={resumen.promedio ?? '—'} />
                </>
              ) : (
                <>
                  <Stat label="Actividades" value={resumen.total_actividades ?? 0} />
                  <Stat label="Entregas recibidas" value={resumen.total_entregas ?? 0} />
                  <Stat label="Fichas" value={resumen.total_fichas ?? 0} />
                </>
              )}
            </div>
          )}

          <div style={styles.menuGrid}>
            {menuItems.map((item) => (
              <div key={item.title} style={styles.card} onClick={() => navigate(item.path)}>
                <div style={styles.cardIcon}>{item.icon}</div>
                <h3 style={styles.cardTitle}>{item.title}</h3>
                <p style={styles.cardDesc}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <footer style={styles.footer}>© 2026 Sistema de Aprendizaje Virtual | SENA Bogotá</footer>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div style={styles.stat}>
      <span style={styles.statValue}>{value}</span>
      <span style={styles.statLabel}>{label}</span>
    </div>
  );
}

const styles = {
  body: {
    minHeight: '100vh',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    backgroundAttachment: 'fixed',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  overlay: {
    minHeight: '100vh',
    backgroundColor: 'rgba(15, 23, 42, 0.45)',
    backdropFilter: 'blur(2px)',
    display: 'flex',
    flexDirection: 'column',
  },
  navbar: {
    background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%)',
    padding: '15px 30px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    color: 'white',
    boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    flexWrap: 'wrap',
    gap: '10px',
  },
  logo: { fontSize: '20px', margin: 0, fontWeight: '700' },
  userInfo: { display: 'flex', alignItems: 'center', gap: '15px' },
  avatar: {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    background: 'white',
    color: '#667eea',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 'bold',
    fontSize: '16px',
  },
  btnLogout: {
    background: 'rgba(255,255,255,0.2)',
    border: '1px solid rgba(255, 255, 255, 0.4)',
    padding: '8px 15px',
    borderRadius: '8px',
    color: 'white',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
  },
  container: { maxWidth: '1100px', margin: '36px auto', padding: '0 20px', width: '100%', boxSizing: 'border-box', flex: 1 },
  welcome: { textAlign: 'center', marginBottom: '26px', color: 'white', textShadow: '0 2px 8px rgba(0, 0, 0, 0.6)' },
  error: {
    background: '#ffe6e6',
    color: '#b91c1c',
    padding: '12px 16px',
    borderRadius: '10px',
    marginBottom: '20px',
    fontSize: '14px',
  },
  stats: { display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '28px' },
  stat: {
    background: 'rgba(255,255,255,0.94)',
    borderRadius: '14px',
    padding: '16px 28px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minWidth: '130px',
    boxShadow: '0 8px 20px rgba(0,0,0,0.15)',
  },
  statValue: { fontSize: '26px', fontWeight: '800', color: '#4c51bf' },
  statLabel: { fontSize: '12px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.6px', fontWeight: '700' },
  menuGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '25px' },
  card: {
    background: 'rgba(255, 255, 255, 0.94)',
    padding: '32px 24px',
    borderRadius: '16px',
    textAlign: 'center',
    cursor: 'pointer',
    boxShadow: '0 8px 25px rgba(0,0,0,0.18)',
    transition: 'transform 0.2s ease, box-shadow 0.2s ease',
  },
  cardIcon: {
    width: '70px',
    height: '70px',
    margin: '0 auto 18px',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    borderRadius: '20px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '35px',
    boxShadow: '0 6px 15px rgba(102, 126, 234, 0.35)',
  },
  cardTitle: { color: '#1e293b', fontSize: '19px', marginBottom: '8px', fontWeight: '700' },
  cardDesc: { color: '#64748b', fontSize: '14px', lineHeight: '1.5', margin: 0 },
  footer: { textAlign: 'center', padding: '25px 20px', color: 'rgba(255, 255, 255, 0.9)', fontSize: '14px' },
};
