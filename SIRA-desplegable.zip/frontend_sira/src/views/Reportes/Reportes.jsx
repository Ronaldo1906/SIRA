import React, { useCallback, useEffect, useState } from 'react';
import PageShell from '../../components/layout/PageShell';
import API from '../../services/api';
import { getSesion } from '../../services/session';

const fmtFecha = (valor) => {
  if (!valor) return '—';
  const d = new Date(valor);
  return Number.isNaN(d.getTime()) ? String(valor) : d.toLocaleString('es-CO', { dateStyle: 'medium', timeStyle: 'short' });
};

export default function Reportes() {
  const sesion = getSesion();
  const esInstructor = sesion.rol === 'INSTRUCTOR';

  const [pendientes, setPendientes] = useState([]);
  const [historial, setHistorial] = useState([]);
  const [resumen, setResumen] = useState(null);
  const [notas, setNotas] = useState({});
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [guardando, setGuardando] = useState(null);

  const cargar = useCallback(async () => {
    if (!sesion.id_usuario) return;
    setCargando(true);
    setError('');
    try {
      if (esInstructor) {
        const { data } = await API.get(`/instructores/${sesion.id_usuario}/entregas-pendientes`);
        setPendientes(data);
      } else {
        const [rep, hist] = await Promise.all([
          API.get(`/reportes/aprendiz/${sesion.id_usuario}`),
          API.get(`/aprendices/${sesion.id_usuario}/historial-entregas`),
        ]);
        setResumen(rep.data);
        setHistorial(hist.data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }, [esInstructor, sesion.id_usuario]);

  useEffect(() => {
    cargar();
  }, [cargar]);

  const calificar = async (idEntrega) => {
    const entrada = notas[idEntrega] || {};
    const nota = Number(entrada.nota);
    if (!Number.isFinite(nota) || nota < 0 || nota > 5) {
      setError('La nota debe estar entre 0.0 y 5.0');
      return;
    }
    setError('');
    setAviso('');
    setGuardando(idEntrega);
    try {
      await API.post('/retroalimentaciones', {
        id_entrega: idEntrega,
        id_instructor: sesion.id_usuario,
        nota,
        descripcion: entrada.descripcion || null,
      });
      setAviso('Calificación guardada correctamente');
      setNotas((prev) => ({ ...prev, [idEntrega]: { nota: '', descripcion: '' } }));
      cargar();
    } catch (err) {
      setError(err.message);
    } finally {
      setGuardando(null);
    }
  };

  return (
    <PageShell
      title="📊 Reportes y Calificaciones"
      subtitle={esInstructor ? 'Evalúa las entregas recibidas de tus aprendices' : 'Consulta tus notas y el estado de tus entregas'}
    >
      {error && <div style={styles.alertError}>{error}</div>}
      {aviso && <div style={styles.alertOk}>{aviso}</div>}

      {cargando ? (
        <p style={styles.info}>Cargando información...</p>
      ) : esInstructor ? (
        pendientes.length === 0 ? (
          <p style={styles.info}>No tienes entregas pendientes por evaluar.</p>
        ) : (
          <div style={styles.lista}>
            {pendientes.map((p) => (
              <div key={p.id_entrega} style={styles.card}>
                <div style={styles.cardHead}>
                  <div>
                    <h3 style={styles.cardTitle}>{p.titulo}</h3>
                    <p style={styles.cardMeta}>
                      {p.nombres} {p.apellidos} · {p.tipo_actividad || 'Actividad'} · Entregado: {fmtFecha(p.fecha_entrega)}
                    </p>
                    {p.archivo && <p style={styles.archivo}>📎 {p.archivo}</p>}
                  </div>
                  <span style={styles.badge}>{p.estado}</span>
                </div>
                <div style={styles.formRow}>
                  <input
                    style={{ ...styles.input, maxWidth: '120px' }}
                    type="number"
                    min="0"
                    max="5"
                    step="0.1"
                    placeholder="Nota 0-5"
                    value={notas[p.id_entrega]?.nota ?? ''}
                    onChange={(e) =>
                      setNotas((prev) => ({
                        ...prev,
                        [p.id_entrega]: { ...prev[p.id_entrega], nota: e.target.value },
                      }))
                    }
                  />
                  <input
                    style={{ ...styles.input, flex: 1, minWidth: '220px' }}
                    type="text"
                    placeholder="Retroalimentación para el aprendiz"
                    value={notas[p.id_entrega]?.descripcion ?? ''}
                    onChange={(e) =>
                      setNotas((prev) => ({
                        ...prev,
                        [p.id_entrega]: { ...prev[p.id_entrega], descripcion: e.target.value },
                      }))
                    }
                  />
                  <button style={styles.btnPrimario} onClick={() => calificar(p.id_entrega)} disabled={guardando === p.id_entrega}>
                    {guardando === p.id_entrega ? 'Guardando...' : 'Calificar'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        <>
          <div style={styles.stats}>
            <Stat label="Promedio" value={resumen?.promedio ?? '—'} />
            <Stat label="Entregas" value={resumen?.total_entregas ?? 0} />
            <Stat label="Evaluadas" value={resumen?.evaluadas ?? 0} />
            <Stat label="Pendientes" value={resumen?.pendientes ?? 0} />
          </div>

          {historial.length === 0 ? (
            <p style={styles.info}>Aún no has realizado entregas.</p>
          ) : (
            <div style={styles.tableWrap}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>Actividad</th>
                    <th style={styles.th}>Entregado</th>
                    <th style={styles.th}>Estado</th>
                    <th style={styles.th}>Nota</th>
                    <th style={styles.th}>Retroalimentación</th>
                  </tr>
                </thead>
                <tbody>
                  {historial.map((h) => (
                    <tr key={h.id_entrega}>
                      <td style={styles.td}>{h.titulo}</td>
                      <td style={styles.td}>{fmtFecha(h.fecha_entrega)}</td>
                      <td style={styles.td}>
                        <span style={styles.estado}>{h.estado}</span>
                      </td>
                      <td style={{ ...styles.td, fontWeight: '700', color: h.nota >= 3 ? '#15803d' : '#b91c1c' }}>
                        {h.nota ?? '—'}
                      </td>
                      <td style={styles.td}>{h.retro_descripcion || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </PageShell>
  );
}

function Stat({ label, value }) {
  return (
    <div style={styles.stat}>
      <span style={styles.statValue}>{value}</span>
      <span style={styles.statLabel}>{label}</span>
    </div>
  );
}

const styles = {
  stats: { display: 'flex', gap: '14px', flexWrap: 'wrap', marginBottom: '22px' },
  stat: {
    background: 'rgba(255,255,255,0.96)',
    borderRadius: '14px',
    padding: '14px 24px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minWidth: '120px',
    boxShadow: '0 8px 20px rgba(0,0,0,0.16)',
  },
  statValue: { fontSize: '24px', fontWeight: '800', color: '#4c51bf' },
  statLabel: { fontSize: '11px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.6px', fontWeight: '700' },
  lista: { display: 'flex', flexDirection: 'column', gap: '16px' },
  card: { background: 'rgba(255,255,255,0.97)', borderRadius: '16px', padding: '20px 22px', boxShadow: '0 10px 24px rgba(0,0,0,0.16)' },
  cardHead: { display: 'flex', justifyContent: 'space-between', gap: '14px', alignItems: 'flex-start', flexWrap: 'wrap' },
  cardTitle: { margin: '0 0 4px', fontSize: '17px', color: '#1e293b' },
  cardMeta: { margin: 0, fontSize: '13px', color: '#64748b' },
  archivo: { margin: '6px 0 0', fontSize: '13px', color: '#15803d', fontWeight: '600' },
  badge: { background: '#dbeafe', color: '#1d4ed8', padding: '6px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '700' },
  formRow: { display: 'flex', gap: '10px', marginTop: '14px', flexWrap: 'wrap', alignItems: 'center' },
  input: {
    padding: '10px 12px',
    borderRadius: '9px',
    border: '1px solid #cbd5e1',
    fontSize: '14px',
    background: 'white',
    color: '#0f172a',
    boxSizing: 'border-box',
  },
  btnPrimario: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '11px 20px',
    borderRadius: '9px',
    cursor: 'pointer',
    fontWeight: '700',
    fontSize: '14px',
  },
  tableWrap: { background: 'rgba(255,255,255,0.97)', borderRadius: '16px', padding: '8px', overflowX: 'auto', boxShadow: '0 10px 24px rgba(0,0,0,0.16)' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '14px' },
  th: { textAlign: 'left', padding: '12px', background: '#f1f5f9', color: '#334155', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  td: { padding: '12px', borderTop: '1px solid #e2e8f0', color: '#334155', verticalAlign: 'top' },
  estado: { background: '#e0e7ff', color: '#3730a3', padding: '4px 10px', borderRadius: '12px', fontSize: '11px', fontWeight: '700' },
  info: { color: 'white', background: 'rgba(15,23,42,0.55)', padding: '16px', borderRadius: '12px' },
  alertError: { background: '#fee2e2', color: '#b91c1c', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
  alertOk: { background: '#dcfce7', color: '#15803d', padding: '12px 16px', borderRadius: '10px', marginBottom: '16px', fontSize: '14px' },
};
