import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import fondoAuditorio from '../../assets/auditorio.jpg';
import { getSesion } from '../../services/session';

/** Marco común de las páginas internas: fondo, barra superior y guardia de sesión. */
export default function PageShell({ title, subtitle, children, maxWidth = '1100px' }) {
  const navigate = useNavigate();
  const sesion = getSesion();

  useEffect(() => {
    if (!sesion.id_usuario) navigate('/login', { replace: true });
  }, [sesion.id_usuario, navigate]);

  const cerrarSesion = () => {
    ['sira_usuario', 'id_usuario', 'rol', 'usuario', 'token'].forEach((k) => localStorage.removeItem(k));
    navigate('/login', { replace: true });
  };

  return (
    <div style={{ ...styles.body, backgroundImage: `url(${fondoAuditorio})` }}>
      <div style={styles.overlay}>
        <nav style={styles.navbar}>
          <div style={styles.brand} onClick={() => navigate('/dashboard')} role="button" tabIndex={0}>
            <span style={styles.logoIcon}>🎓</span> SIRA
          </div>
          <div style={styles.userInfo}>
            <span style={styles.userName}>{sesion.nombre || 'Usuario'}</span>
            <span style={styles.badge}>{sesion.rol}</span>
            <button style={styles.btnSalir} onClick={cerrarSesion}>Salir</button>
          </div>
        </nav>

        <main style={{ ...styles.main, maxWidth }}>
          <button style={styles.btnVolver} onClick={() => navigate('/dashboard')}>
            ← Volver al Dashboard
          </button>
          <header style={styles.header}>
            <h1 style={styles.title}>{title}</h1>
            {subtitle && <p style={styles.subtitle}>{subtitle}</p>}
          </header>
          {children}
        </main>

        <footer style={styles.footer}>© 2026 Sistema de Aprendizaje Virtual | SENA Bogotá</footer>
      </div>
    </div>
  );
}

const styles = {
  body: {
    minHeight: '100vh',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    backgroundAttachment: 'fixed',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  overlay: {
    minHeight: '100vh',
    backgroundColor: 'rgba(15, 23, 42, 0.55)',
    backdropFilter: 'blur(3px)',
    WebkitBackdropFilter: 'blur(3px)',
    display: 'flex',
    flexDirection: 'column',
  },
  navbar: {
    background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.96) 0%, rgba(118, 75, 162, 0.96) 100%)',
    padding: '14px 28px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    color: 'white',
    boxShadow: '0 4px 12px rgba(0,0,0,0.25)',
    position: 'sticky',
    top: 0,
    zIndex: 50,
    flexWrap: 'wrap',
    gap: '10px',
  },
  brand: { fontSize: '20px', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' },
  logoIcon: { fontSize: '22px' },
  userInfo: { display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' },
  userName: { fontSize: '14px', fontWeight: '600' },
  badge: {
    background: 'rgba(255,255,255,0.22)',
    border: '1px solid rgba(255,255,255,0.45)',
    padding: '4px 10px',
    borderRadius: '20px',
    fontSize: '11px',
    fontWeight: '700',
    letterSpacing: '0.5px',
  },
  btnSalir: {
    background: 'rgba(255,255,255,0.18)',
    border: '1px solid rgba(255,255,255,0.45)',
    padding: '7px 14px',
    borderRadius: '8px',
    color: 'white',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: '600',
  },
  main: { width: '100%', margin: '26px auto 10px', padding: '0 20px', flex: 1, boxSizing: 'border-box' },
  btnVolver: {
    background: 'rgba(255,255,255,0.16)',
    color: 'white',
    border: '1px solid rgba(255,255,255,0.4)',
    padding: '9px 18px',
    borderRadius: '10px',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '13px',
    marginBottom: '16px',
  },
  header: { marginBottom: '18px' },
  title: { color: 'white', fontSize: '26px', margin: '0 0 4px', textShadow: '0 2px 8px rgba(0,0,0,0.5)' },
  subtitle: { color: 'rgba(255,255,255,0.85)', margin: 0, fontSize: '14px' },
  footer: { textAlign: 'center', padding: '22px', color: 'rgba(255,255,255,0.85)', fontSize: '13px' },
};
