import { createContext, useContext, useState } from 'react';
import { login as loginService } from '../services/authService';
import { getSesion, guardarSesion, limpiarSesion } from '../services/session';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(() => {
    const sesion = getSesion();
    return sesion.id_usuario ? sesion : null;
  });

  /**
   * @param {string} correo correo o número de documento
   * @param {string} password contraseña
   */
  const login = async (correo, password) => {
    const datos = await loginService({ username: correo, password });
    guardarSesion(datos);
    setUsuario(getSesion());
    return datos;
  };

  const logout = () => {
    limpiarSesion();
    setUsuario(null);
  };

  return (
    <AuthContext.Provider
      value={{
        usuario,
        autenticado: usuario !== null,
        idUsuario: usuario?.id_usuario ?? null,
        rol: usuario?.rol ?? null,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return contexto;
}
