#!/usr/bin/env bash
# Crea la base de datos, el usuario de la app y carga el esquema + datos demo.
# Uso: scripts/init_db.sh [host] [puerto] [usuario_root]
set -euo pipefail
cd "$(dirname "$0")/.."

DB_HOST="${1:-127.0.0.1}"
DB_PORT="${2:-3306}"
ROOT_USER="${3:-root}"

echo "==> Cargando database/init.sql en $DB_HOST:$DB_PORT (usuario $ROOT_USER)"
mysql -h "$DB_HOST" -P "$DB_PORT" -u "$ROOT_USER" -p < database/init.sql

echo "==> Creando usuario 'sira' (contraseña 'sira') con permisos sobre la base"
mysql -h "$DB_HOST" -P "$DB_PORT" -u "$ROOT_USER" -p <<'SQL'
CREATE USER IF NOT EXISTS 'sira'@'localhost' IDENTIFIED BY 'sira';
CREATE USER IF NOT EXISTS 'sira'@'%' IDENTIFIED BY 'sira';
GRANT ALL PRIVILEGES ON sira.* TO 'sira'@'localhost';
GRANT ALL PRIVILEGES ON sira.* TO 'sira'@'%';
FLUSH PRIVILEGES;
SQL

echo "Base de datos lista. Usuario: sira / sira / base: sira"
