#!/usr/bin/env bash
# Arranca la aplicación completa (API + SPA compilada) en http://localhost:8000
set -euo pipefail
cd "$(dirname "$0")/../backend_sira"

if [ ! -f ../.venv/bin/uvicorn ]; then
  echo "No existe .venv. Ejecuta primero scripts/setup.sh" >&2
  exit 1
fi
if [ ! -f static/index.html ]; then
  echo "Frontend no compilado. Ejecutando build..."
  (cd ../frontend_sira && npm run build)
  rm -rf static && cp -r ../frontend_sira/dist static
fi

exec ../.venv/bin/uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
