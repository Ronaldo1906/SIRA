#!/usr/bin/env bash
# Prepara el entorno local: dependencias Python, dependencias Node y build del frontend.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "==> Entorno virtual de Python"
python3 -m venv .venv
./.venv/bin/pip install --upgrade pip >/dev/null
./.venv/bin/pip install -r backend_sira/requirements.txt

echo "==> Dependencias del frontend"
(cd frontend_sira && npm install --no-audit --no-fund)

echo "==> Build del frontend"
(cd frontend_sira && npm run build)
rm -rf backend_sira/static
cp -r frontend_sira/dist backend_sira/static

echo "Listo. Ahora ejecuta: scripts/init_db.sh && scripts/start.sh"
