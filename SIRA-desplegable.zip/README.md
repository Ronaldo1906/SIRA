# SIRA — Sistema de Información de Revisiones y Actividades

Aplicación full-stack (React + FastAPI + MySQL) para gestionar actividades académicas, entregas de evidencias y retroalimentación entre instructores y aprendices del SENA.

Esta versión está **corregida, integrada y desplegada**: frontend, backend y base de datos quedan conectados y probados de extremo a extremo.

---

## 1. Despliegue en vivo

| Elemento | Valor |
| --- | --- |
| URL de la aplicación | https://8000-i98sn1xdxy2ybq1ii7xwp-e2dfb71a.us5.manus.computer |
| Documentación interactiva (Swagger) | https://8000-i98sn1xdxy2ybq1ii7xwp-e2dfb71a.us5.manus.computer/docs |
| Estado del servicio y de la base de datos | https://8000-i98sn1xdxy2ybq1ii7xwp-e2dfb71a.us5.manus.computer/api/health |

### Cuentas de prueba

Todos los usuarios sembrados comparten la contraseña **`sira123`**.

| Rol | Usuario | Contraseña |
| --- | --- | --- |
| Instructor | `maria.gomez1@sena.edu.co` | `sira123` |
| Aprendiz | `maria.gomez21@sena.edu.co` | `sira123` |
| También se puede entrar con el número de documento | `20000001` / `20000021` | `sira123` |

> La instancia de demostración corre en un entorno temporal de Manus. Si el enlace deja de responder, la aplicación se levanta de nuevo con `docker compose up -d --build` (ver sección 4) o con `scripts/start.sh`.

---

## 2. Arquitectura

Un solo proceso sirve la API y el frontend compilado, lo que elimina los problemas de CORS y de URLs absolutas que tenía el proyecto original.

```
Navegador
   │  HTTPS
   ▼
FastAPI (puerto 8000)
   ├── /api/...      → API REST (SQLAlchemy + PyMySQL)
   ├── /uploads/...  → archivos subidos (entregas y material)
   ├── /docs         → Swagger
   └── /*            → SPA de React (build de Vite)
                          │
                          ▼
                    MySQL / MariaDB
```

| Capa | Tecnología |
| --- | --- |
| Frontend | React 19, Vite 8, React Router 7, Axios, CSS en JS |
| Backend | Python 3.12, FastAPI, Uvicorn, Pydantic v2, SQLAlchemy 2, PyMySQL |
| Base de datos | MySQL 8 / MariaDB 11 (`database/init.sql`) |
| Empaquetado | Docker multi-stage + Docker Compose |

---

## 3. Qué se corrigió respecto al ZIP original

El proyecto original no arrancaba. Estos eran los bloqueos reales y su solución:

| # | Problema encontrado | Efecto | Solución aplicada |
| --- | --- | --- | --- |
| 1 | `src/main.jsx` importaba `./app.jsx` y el archivo es `App.jsx` | En Linux/Docker el build falla (en Windows funciona por ser insensible a mayúsculas) | Import corregido a `./App.jsx` |
| 2 | La tabla `Usuario` no tenía columna `password`, pero el login hacía `SELECT u.password` | **Ningún inicio de sesión funcionaba** | Columna añadida al esquema, con contraseñas cifradas en SHA-256 |
| 3 | `AuthContext` llamaba `loginService(correo, password)` cuando el servicio espera un objeto, y esperaba `{status, data}` que la API nunca devuelve | El usuario nunca quedaba autenticado | Flujo de login reescrito y centralizado en `AuthContext` |
| 4 | `api.js` usaba `baseURL: http://localhost:8000/api`, pero la mayoría de endpoints estaban en la raíz (`/actividades`, `/usuarios`) | 404 en casi todas las peticiones | Todos los endpoints viven bajo `/api` y el cliente usa rutas relativas |
| 5 | URLs `http://localhost:8000` escritas a mano en las vistas | Solo funcionaba en la máquina del desarrollador | Cliente Axios único (`src/services/api.js`) con proxy de Vite en desarrollo |
| 6 | Consultas SQL usaban `f.codigo_ficha`, la columna real es `numero_ficha` | Error SQL en reportes y selects | Consultas y esquemas Pydantic alineados a `numero_ficha` |
| 7 | `models.Usuario(**usuario.model_dump())` recibía `contrasena` en vez de `password` | Error al crear usuarios | Inserción explícita con hash de contraseña |
| 8 | `UsuarioResponse` exponía la contraseña y esperaba un atributo inexistente | Error 500 al listar usuarios | Respuesta sin datos sensibles |
| 9 | CORS solo permitía `http://localhost:5173` | La app desplegada no podía llamar a la API | CORS configurable por variable `CORS_ORIGINS` (por defecto `*`) |
| 10 | `docker-compose.yml` no incluía base de datos y apuntaba a `192.168.100.42` | `docker compose up` no levantaba nada útil | Compose con MariaDB + app, healthchecks y volúmenes |
| 11 | Las vistas de Actividades, Material y Reportes usaban datos inventados en el estado de React | La interfaz no reflejaba la base de datos | Todas las vistas consumen la API real (listar, crear, subir, calificar, borrar) |
| 12 | El ZIP incluía `node_modules` de Windows, `__pycache__`, una copia duplicada del backend y hasta marcadores de conflicto de Git (`<<<<<<< HEAD`) | Ruido y errores de instalación | Repositorio limpio y reproducible |

Además se agregó lo que faltaba para que el sistema fuera realmente usable: subida de archivos (entregas y material), descarga de material, borrado de actividades con eliminación en cascada, cambio de contraseña, notificaciones y un endpoint de salud.

---

## 4. Ejecución con Docker (recomendado)

Requisitos: Docker y Docker Compose.

```bash
# 1. Variables de entorno (opcional: .env ya trae valores por defecto)
#    Edita .env si quieres cambiar contraseñas antes de levantar

# 2. Construir y levantar base de datos + aplicación
docker compose up -d --build

# 3. Ver logs / estado
docker compose logs -f app
docker compose ps
```

Abrir **http://localhost:8000**.

La primera vez, MariaDB ejecuta automáticamente `database/init.sql` (esquema + 420 usuarios + actividades + entregas demo). Los datos quedan en los volúmenes `db_data` y `uploads_data`, así que sobreviven a reinicios.

Comandos útiles:

```bash
docker compose down            # detener (conserva datos)
docker compose down -v         # detener y borrar datos (reinicia la demo)
docker compose exec db mariadb -usira -psira sira   # consola SQL
```

---

## 5. Ejecución local sin Docker

Requisitos: Python 3.10+, Node 18+, MySQL/MariaDB en marcha.

```bash
# 1. Dependencias, build del frontend y copia a backend_sira/static
./scripts/setup.sh

# 2. Crear base de datos, usuario y cargar datos (pide la clave de root de MySQL)
./scripts/init_db.sh

# 3. Arrancar todo en http://localhost:8000
./scripts/start.sh
```

### Modo desarrollo (frontend con recarga en caliente)

```bash
# Terminal 1 — API con autoreload
cd backend_sira
../.venv/bin/uvicorn app.main:app --reload --port 8000

# Terminal 2 — Vite en http://localhost:5173
cd frontend_sira
npm run dev
```

Vite reenvía `/api` y `/uploads` a `http://127.0.0.1:8000` (ver `vite.config.js`), por eso no hay que configurar ninguna URL absoluta.

---

## 6. API

Documentación interactiva completa en `/docs`. Todos los endpoints cuelgan de `/api`.

| Método | Ruta | Descripción |
| --- | --- | --- |
| GET | `/api/health` | Estado de la API y de la base de datos |
| POST | `/api/login` | Autenticación (email o documento + contraseña) |
| GET | `/api/usuarios` | Listado de usuarios con su rol |
| POST | `/api/usuarios` | Crear usuario |
| GET | `/api/usuarios/{id}/perfil` | Perfil completo (rol, ficha, programa, teléfonos) |
| PUT | `/api/usuarios/{id}/password` | Cambiar contraseña |
| GET | `/api/usuarios/{id}/notificaciones-no-leidas` | Notificaciones pendientes |
| GET | `/api/fichas` | Fichas (filtrable por instructor) |
| GET | `/api/fichas/promedio-notas` | Promedio de notas por ficha |
| GET | `/api/fichas/resumen-programas` | Resumen por programa |
| GET | `/api/actividades` | Actividades con ficha, instructor y avance |
| POST | `/api/actividades` | Crear actividad |
| DELETE | `/api/actividades/{id}` | Eliminar actividad (cascada) |
| GET | `/api/actividades/{id}/pendientes-entrega` | Aprendices que no han entregado |
| GET | `/api/actividades/{id}/materiales` | Material de una actividad |
| GET | `/api/aprendices/{id}/actividades` | Actividades del aprendiz con estado y nota |
| GET | `/api/aprendices/{id}/actividades-pendientes` | Actividades sin entregar |
| GET | `/api/aprendices/{id}/historial-entregas` | Historial de entregas y notas |
| GET | `/api/instructores/{id}/actividades-avance` | Avance de entregas por actividad |
| GET | `/api/instructores/{id}/entregas-pendientes` | Entregas por evaluar |
| POST | `/api/entregas` | Registrar entrega (JSON) |
| POST | `/api/entregas/upload` | Registrar entrega con archivo (multipart) |
| GET | `/api/entregas/{id}/detalle` | Detalle de entrega + retroalimentación |
| POST | `/api/retroalimentaciones` | Calificar entrega (0.0–5.0) |
| GET/POST | `/api/retroalimentaciones/{id}/comentarios` | Hilo de comentarios |
| GET | `/api/materiales` | Material académico publicado |
| POST | `/api/materiales/upload` | Subir material (multipart) |
| GET | `/api/materiales/{id}/descargar` | Descargar material |
| DELETE | `/api/materiales/{id}` | Eliminar material |
| GET | `/api/reportes/aprendiz/{id}` | Promedio, entregas y pendientes |

---

## 7. Pruebas

Con la aplicación en marcha:

```bash
./.venv/bin/pip install requests      # solo la primera vez
./.venv/bin/python tests/e2e_test.py http://127.0.0.1:8000
```

El script recorre 32 comprobaciones: salud y conexión a la base de datos, login de instructor y aprendiz (incluido login por documento y rechazo de contraseña inválida), perfiles, listados, creación de actividad, subida de entrega con archivo, calificación, reporte del aprendiz, subida/descarga/borrado de material, borrado en cascada y entrega de la SPA.

Resultado esperado: `Resultado: 32 comprobaciones OK, 0 fallos`.

---

## 8. Estructura del proyecto

```
SIRA/
├── backend_sira/
│   ├── app/
│   │   ├── config.py        # configuración por variables de entorno
│   │   ├── database.py      # engine y sesión SQLAlchemy
│   │   ├── models.py        # modelos ORM
│   │   ├── schemas.py       # esquemas Pydantic
│   │   └── main.py          # API + servicio de la SPA
│   ├── uploads/             # archivos subidos (demo incluida)
│   ├── static/              # build del frontend (generado)
│   ├── Dockerfile           # multi-stage: build React + runtime Python
│   └── requirements.txt
├── frontend_sira/
│   ├── src/
│   │   ├── components/      # PageShell y componentes reutilizables
│   │   ├── context/         # AuthContext
│   │   ├── services/        # api.js, authService.js, session.js
│   │   └── views/           # Login, Dashboard, Perfil, Actividades, Material, Reportes
│   ├── vite.config.js       # proxy /api y /uploads
│   └── package.json
├── database/
│   ├── init.sql             # esquema + datos demo (idempotente)
│   ├── build_init_sql.py    # genera init.sql desde el script original
│   ├── create_demo_files.py # archivos de ejemplo descargables
│   └── RONALDO.original.sql # script original del proyecto
├── tests/e2e_test.py
├── scripts/                 # setup.sh, init_db.sh, start.sh
├── docker-compose.yml
└── README.md
```

---

## 9. Despliegue en la nube (24/7)

La aplicación es un contenedor sin estado (los archivos van a un volumen), así que funciona en cualquier plataforma que ejecute Docker.

### Render / Railway / Fly.io

1. Sube el repositorio a GitHub.
2. Crea un servicio web desde `backend_sira/Dockerfile` **con el contexto en la raíz del repo** (el Dockerfile compila el frontend).
3. Añade una base MySQL/MariaDB gestionada y define:
   - `DATABASE_URL` (o `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`)
   - `SECRET_KEY` con un valor aleatorio
   - `CORS_ORIGINS` con tu dominio
4. Importa `database/init.sql` en la base gestionada (consola SQL o `mysql -h ... < database/init.sql`).
5. Monta un disco persistente en `/app/uploads`.

### VPS con Docker

```bash
git clone <tu-repo> sira && cd sira
cp .env.example .env    # ajusta contraseñas
docker compose up -d --build
```

Delante del puerto 8000 conviene poner Nginx/Caddy con HTTPS (Caddy: `reverse_proxy 127.0.0.1:8000`).

---

## 10. Notas de seguridad

El proyecto académico original guardaba contraseñas en texto plano. Aquí se almacenan como SHA-256 y la comparación es en tiempo constante; además el backend acepta contraseñas heredadas en texto plano para no romper datos antiguos (se recomienda migrarlas).

Para un entorno real conviene además: usar bcrypt/Argon2, emitir JWT firmados con expiración y proteger los endpoints con dependencias de autenticación por rol. El token actual es un identificador firmado con HMAC que el frontend envía en `Authorization`, suficiente para la sustentación pero no para producción.

---

## 11. Solución de problemas

| Síntoma | Causa probable | Solución |
| --- | --- | --- |
| `503 Frontend no compilado` | Falta `backend_sira/static` | `cd frontend_sira && npm run build` y copiar `dist` a `backend_sira/static` |
| `database: "error: ..."` en `/api/health` | MySQL no responde o credenciales incorrectas | Revisar `DB_*` en `.env` y que el contenedor `db` esté `healthy` |
| `Access denied for user 'sira'` | No se creó el usuario o se borró la base | Ejecutar `scripts/init_db.sh` o recrear el volumen |
| El login devuelve 401 con datos demo | Contraseña distinta de `sira123` o datos no cargados | Recargar `database/init.sql` |
| Los cambios del frontend no aparecen | Se sirve el build antiguo | `npm run build` y volver a copiar `dist` a `backend_sira/static` |
