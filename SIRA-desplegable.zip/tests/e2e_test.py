#!/usr/bin/env python3
"""Prueba end-to-end de la API SIRA contra un servidor en marcha.

Uso:
    python tests/e2e_test.py [http://127.0.0.1:8000]

Verifica: salud + base de datos, login de instructor y aprendiz, listados,
creación de actividad, subida de entrega (multipart), calificación,
materiales (subida/descarga/borrado) y borrado en cascada de la actividad.
"""
from __future__ import annotations

import io
import sys
import time

import requests

BASE = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000").rstrip("/")
API = f"{BASE}/api"
PASSWORD = "sira123"

ok = 0
fallos: list[str] = []


def check(nombre: str, condicion: bool, extra: str = "") -> None:
    global ok
    if condicion:
        ok += 1
        print(f"  OK   {nombre}")
    else:
        fallos.append(f"{nombre} {extra}".strip())
        print(f"  FAIL {nombre} {extra}".strip())


print(f"Probando {BASE}\n")

# 1. Salud ---------------------------------------------------------------
print("1) Salud y base de datos")
r = requests.get(f"{API}/health", timeout=10)
check("GET /api/health responde 200", r.status_code == 200, str(r.status_code))
salud = r.json() if r.status_code == 200 else {}
check("base de datos conectada", salud.get("database") == "ok", str(salud))
check("hay usuarios cargados", salud.get("registros", {}).get("usuarios", 0) > 0, str(salud))

# 2. Login ---------------------------------------------------------------
print("\n2) Autenticación")
r = requests.post(f"{API}/login", json={"username": "maria.gomez1@sena.edu.co", "password": PASSWORD}, timeout=10)
check("login instructor", r.status_code == 200, r.text[:200])
instructor = r.json() if r.status_code == 200 else {}
check("rol instructor", instructor.get("rol") == "INSTRUCTOR", str(instructor.get("rol")))
check("token presente", bool(instructor.get("token")))

r = requests.post(f"{API}/login", json={"username": "maria.gomez21@sena.edu.co", "password": PASSWORD}, timeout=10)
check("login aprendiz", r.status_code == 200, r.text[:200])
aprendiz = r.json() if r.status_code == 200 else {}
check("rol aprendiz", aprendiz.get("rol") == "APRENDIZ", str(aprendiz.get("rol")))

r = requests.post(f"{API}/login", json={"username": "maria.gomez1@sena.edu.co", "password": "incorrecta"}, timeout=10)
check("rechaza contraseña inválida", r.status_code == 401, str(r.status_code))

r = requests.post(f"{API}/login", json={"username": "20000001", "password": PASSWORD}, timeout=10)
check("login por número de documento", r.status_code == 200, str(r.status_code))

id_instructor = instructor.get("id_usuario", 1)
id_aprendiz = aprendiz.get("id_usuario", 21)

# 3. Perfil y listados ---------------------------------------------------
print("\n3) Perfil y listados")
r = requests.get(f"{API}/usuarios/{id_instructor}/perfil", timeout=10)
check("perfil instructor", r.status_code == 200 and r.json().get("rol") == "INSTRUCTOR", r.text[:200])
r = requests.get(f"{API}/usuarios/{id_aprendiz}/perfil", timeout=10)
check("perfil aprendiz con ficha", r.status_code == 200 and r.json().get("numero_ficha"), r.text[:200])
r = requests.get(f"{API}/actividades", timeout=10)
check("listado de actividades", r.status_code == 200 and len(r.json()) >= 20, r.text[:200])
r = requests.get(f"{API}/aprendices/{id_aprendiz}/actividades", timeout=10)
check("actividades del aprendiz", r.status_code == 200 and len(r.json()) > 0, r.text[:200])
r = requests.get(f"{API}/fichas?id_instructor={id_instructor}", timeout=10)
check("fichas del instructor", r.status_code == 200 and len(r.json()) > 0, r.text[:200])
fichas = r.json()
id_ficha = fichas[0]["id_ficha"] if fichas else 1

# 4. Crear actividad -----------------------------------------------------
print("\n4) Crear actividad")
r = requests.post(
    f"{API}/actividades",
    json={
        "titulo": "Actividad de prueba E2E",
        "descripcion": "Creada por tests/e2e_test.py",
        "fecha_vencimiento": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(time.time() + 86400 * 7)),
        "tipo_actividad": "Taller",
        "id_instructor": id_instructor,
        "id_ficha": id_ficha,
    },
    timeout=10,
)
check("POST /api/actividades", r.status_code == 201, r.text[:300])
actividad = r.json() if r.status_code == 201 else {}
id_actividad = actividad.get("id_actividad")

if id_actividad:
    # 5. Entrega con archivo ---------------------------------------------
    print("\n5) Entrega con archivo")
    r = requests.post(
        f"{API}/entregas/upload",
        data={"id_actividad": id_actividad, "id_aprendiz": id_aprendiz},
        files={"archivo": ("evidencia.txt", io.BytesIO(b"Evidencia de prueba E2E"), "text/plain")},
        timeout=15,
    )
    check("POST /api/entregas/upload", r.status_code == 201, r.text[:300])
    entrega = r.json() if r.status_code == 201 else {}
    id_entrega = entrega.get("id_entrega")
    check("entrega en estado ENVIADO", entrega.get("estado") == "ENVIADO", str(entrega.get("estado")))
    check("archivo accesible", requests.get(f"{BASE}{entrega.get('url_archivo','')}", timeout=10).status_code == 200)

    r = requests.get(f"{API}/instructores/{id_instructor}/entregas-pendientes", timeout=10)
    pendientes = r.json() if r.status_code == 200 else []
    check("entrega aparece como pendiente de evaluar", any(p.get("id_entrega") == id_entrega for p in pendientes))

    # 6. Calificar ------------------------------------------------------
    print("\n6) Calificación y retroalimentación")
    r = requests.post(
        f"{API}/retroalimentaciones",
        json={"id_entrega": id_entrega, "id_instructor": id_instructor, "nota": 4.7, "descripcion": "Buen trabajo (E2E)"},
        timeout=10,
    )
    check("POST /api/retroalimentaciones", r.status_code == 201, r.text[:300])
    r = requests.get(f"{API}/entregas/{id_entrega}/detalle", timeout=10)
    detalle = r.json() if r.status_code == 200 else {}
    check("entrega queda EVALUADO", detalle.get("estado") == "EVALUADO", str(detalle.get("estado")))
    check("nota guardada", float(detalle.get("nota") or 0) == 4.7, str(detalle.get("nota")))

    r = requests.get(f"{API}/reportes/aprendiz/{id_aprendiz}", timeout=10)
    check("reporte del aprendiz", r.status_code == 200 and "promedio" in r.json(), r.text[:200])

    # 7. Material -------------------------------------------------------
    print("\n7) Material académico")
    r = requests.post(
        f"{API}/materiales/upload",
        data={"id_actividad": id_actividad, "id_instructor": id_instructor},
        files={"archivo": ("guia_e2e.pdf", io.BytesIO(b"%PDF-1.4 prueba"), "application/pdf")},
        timeout=15,
    )
    check("POST /api/materiales/upload", r.status_code == 201, r.text[:300])
    material = r.json() if r.status_code == 201 else {}
    id_material = material.get("id_repositorio")
    r = requests.get(f"{API}/materiales/{id_material}/descargar", timeout=10)
    check("descarga de material", r.status_code == 200, str(r.status_code))
    r = requests.delete(f"{API}/materiales/{id_material}", timeout=10)
    check("DELETE material", r.status_code == 200, r.text[:200])

    # 8. Borrado en cascada --------------------------------------------
    print("\n8) Borrado de la actividad de prueba")
    r = requests.delete(f"{API}/actividades/{id_actividad}", timeout=10)
    check("DELETE /api/actividades/{id}", r.status_code == 200, r.text[:300])
    r = requests.get(f"{API}/entregas/{id_entrega}", timeout=10)
    check("entrega eliminada en cascada", r.status_code == 404, str(r.status_code))

# 9. Frontend ------------------------------------------------------------
print("\n9) Frontend (SPA)")
r = requests.get(f"{BASE}/", timeout=10)
check("GET / sirve index.html", r.status_code == 200 and "text/html" in r.headers.get("content-type", ""), str(r.status_code))
r = requests.get(f"{BASE}/dashboard", timeout=10)
check("ruta SPA /dashboard devuelve HTML", r.status_code == 200 and "<div id=\"root\">" in r.text, str(r.status_code))
r = requests.get(f"{BASE}/api/no-existe", timeout=10)
check("endpoint inexistente devuelve 404", r.status_code == 404, str(r.status_code))

print(f"\nResultado: {ok} comprobaciones OK, {len(fallos)} fallos")
if fallos:
    for f in fallos:
        print(f"  - {f}")
    sys.exit(1)
print("Todo correcto.")
