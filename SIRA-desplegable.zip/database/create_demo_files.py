#!/usr/bin/env python3
"""Genera los archivos de ejemplo que referencia database/init.sql.

Requiere (solo para este script): fpdf2, openpyxl, python-docx
    pip install fpdf2 openpyxl python-docx

Uso:
    python database/create_demo_files.py
"""
from __future__ import annotations

import zipfile
from pathlib import Path

from docx import Document
from fpdf import FPDF
from openpyxl import Workbook

BASE = Path(__file__).resolve().parent.parent / "backend_sira" / "uploads" / "demo"
BASE.mkdir(parents=True, exist_ok=True)


def pdf(nombre: str, titulo: str, lineas: list[str]) -> None:
    doc = FPDF()
    doc.add_page()
    doc.set_font("Helvetica", "B", 17)
    doc.multi_cell(0, 10, titulo, align="C")
    doc.ln(6)
    doc.set_font("Helvetica", "", 11)
    for linea in lineas:
        doc.multi_cell(0, 7, linea)
        doc.ln(2)
    doc.output(str(BASE / nombre))
    print("PDF  ", nombre)


def xlsx(nombre: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Estados financieros"
    ws.append(["Concepto", "Valor"])
    for concepto, valor in [
        ("Ingresos operacionales", 12500000),
        ("Costos de ventas", 7400000),
        ("Gastos administrativos", 2100000),
        ("Utilidad bruta", 5100000),
        ("Utilidad neta", 3000000),
    ]:
        ws.append([concepto, valor])
    wb.save(BASE / nombre)
    print("XLSX ", nombre)


def docx(nombre: str) -> None:
    doc = Document()
    doc.add_heading("Plan de mercadeo - Plantilla SIRA", level=1)
    doc.add_paragraph("1. Objetivo del plan")
    doc.add_paragraph("2. Publico objetivo y segmentacion")
    doc.add_paragraph("3. Mezcla de marketing (producto, precio, plaza, promocion)")
    doc.add_paragraph("4. Presupuesto y cronograma")
    doc.save(BASE / nombre)
    print("DOCX ", nombre)


def zipfile_demo(nombre: str) -> None:
    ruta = BASE / nombre
    with zipfile.ZipFile(ruta, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(
            "consultas.sql",
            "-- Consultas del taller\nSELECT f.numero_ficha, COUNT(*) AS aprendices\n"
            "FROM Ficha f JOIN Aprendiz a ON a.id_ficha = f.id_ficha\nGROUP BY f.numero_ficha;\n",
        )
        z.writestr("README.txt", "Evidencia del taller de consultas SQL - SIRA\n")
    print("ZIP  ", nombre)


pdf("Guia_Proyecto_Integrador.pdf", "SIRA - Guia del Proyecto Integrador", [
    "Objetivo: documentar el diseno de una plataforma de gestion academica (SIRA).",
    "Entregables: PDF con arquitectura, modelo entidad-relacion y manual de uso.",
    "Criterios: modelo de datos (30%), API funcional (40%), interfaz (20%), sustentacion (10%).",
])
pdf("Rubrica_Sustentacion.pdf", "SIRA - Rubrica de Sustentacion", [
    "Dominio del tema: 30%", "Calidad tecnica de la solucion: 30%",
    "Claridad de la exposicion: 20%", "Respuesta a preguntas del jurado: 20%",
])
pdf("guia_variables.pdf", "Guia - Variables y tipos de datos", [
    "Una variable es un espacio en memoria con nombre y tipo.",
    "Tipos primitivos: entero, decimal, cadena, booleano.",
    "Ejercicio: declare variables y muestre su valor por consola.",
])
pdf("brief_identidad_visual.pdf", "Brief - Identidad visual", [
    "Marca: nombre, promesa de valor y personalidad.",
    "Paleta de color, tipografias y usos correctos del logo.",
    "Entregable: manual de marca de maximo 10 paginas.",
])
pdf("guia_gestion_documental.pdf", "Guia - Gestion documental", [
    "Clasificacion de archivos fisicos y digitales.",
    "Tabla de retencion documental y rotulado de cajas.",
])
pdf("manual_redes_lan.pdf", "Manual - Redes LAN", [
    "Topologias, direccionamiento IPv4 y mascaras de subred.",
    "Practica: configurar una red con switch y validar conectividad.",
])
pdf("recetario_base.pdf", "Recetario base - Tecnicas culinarias", [
    "Fondos, salsas madre y tecnicas de coccion.",
    "Fichas tecnicas con rendimiento y costo por porcion.",
])
pdf("normas_seguridad.pdf", "Normas de seguridad industrial", [
    "Elementos de proteccion personal y senalizacion.",
    "Matriz de riesgos y protocolo de reporte de incidentes.",
])
pdf("guia_rutas_logisticas.pdf", "Guia - Rutas logisticas", [
    "Diseno de rutas de distribucion y ventanas horarias.",
    "Indicadores: costo por kilometro y nivel de servicio.",
])
pdf("guia_edicion_video.pdf", "Guia - Edicion de video", [
    "Guion, storyboard y ritmo narrativo.",
    "Exportacion para redes sociales: formatos y resoluciones.",
])
xlsx("plantilla_estados_financieros.xlsx")
docx("plantilla_plan_mercadeo.docx")
zipfile_demo("consultas_juan.zip")

print(f"\nArchivos generados en {BASE}")
