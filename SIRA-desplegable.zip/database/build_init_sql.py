#!/usr/bin/env python3
"""Genera database/init.sql a partir de RONALDO.sql aplicando correcciones:
- Base de datos recreable (DROP/CREATE con utf8mb4)
- Columna `password` en Usuario (el backend la necesita para autenticar)
- Datos demo con fechas futuras para que la app sea usable
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
src = (ROOT / "database" / "RONALDO.original.sql").read_text(encoding="utf-8-sig")

header_old = "CREATE DATABASE sira;\nUSE sira;"
# No se hace DROP DATABASE a propósito: en contenedores MySQL/MariaDB eso borra
# los privilegios del usuario de la app sobre la base. Se recrean las tablas.
header_new = (
    "CREATE DATABASE IF NOT EXISTS sira CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n"
    "USE sira;\n"
    "SET FOREIGN_KEY_CHECKS = 0;\n"
    "DROP TABLE IF EXISTS Notificacion, Repositorio, Comentario, Retroalimentacion,\n"
    "    Entrega, Actividad, Resultado_Aprendizaje, Competencia, Aprendiz, Ficha,\n"
    "    Programa_Formacion, Instructor, Usuario;\n"
    "SET FOREIGN_KEY_CHECKS = 1;"
)
assert header_old in src, "No se encontro el encabezado CREATE DATABASE"
src = src.replace(header_old, header_new, 1)

# La tabla Usuario del script original no tiene password: el backend hace
# SELECT u.password, por lo que sin esta columna el login falla siempre.
old_email = "    email          VARCHAR(100) UNIQUE NOT NULL,\n"
new_email = (
    "    email          VARCHAR(100) UNIQUE NOT NULL,\n"
    "    password       VARCHAR(255) NOT NULL DEFAULT 'sira123',\n"
)
assert old_email in src
src = src.replace(old_email, new_email, 1)

demo = """

-- ============================================================
-- 13. CREDENCIALES Y DATOS DEMO (fechas futuras)
-- ------------------------------------------------------------
-- Todos los usuarios comparten la clave demo: sira123
-- (almacenada como SHA-256; el backend tambien acepta texto plano legado)
-- ============================================================
UPDATE Usuario SET password = SHA2('sira123', 256);

-- Actividades vigentes para que el flujo de entrega sea demostrable
INSERT INTO Actividad (titulo, descripcion, fecha_vencimiento, tipo_actividad, id_instructor, id_ficha, id_resultado) VALUES
('Proyecto integrador SIRA','Documento con el diseno del sistema y su modelo de datos','2026-12-15 23:59:00','Proyecto',1,1,1),
('Taller de consultas SQL','Ejercicios de consultas con JOIN y funciones de agregacion','2026-12-05 23:59:00','Taller',1,1,2),
('Quiz de API REST','Evaluacion de conceptos de FastAPI y HTTP','2026-12-20 23:59:00','Quiz',1,1,3),
('Sustentacion final','Presentacion del proyecto ante el comite evaluador','2027-01-15 23:59:00','Evaluacion',2,2,2);

-- Material academico cargado por los instructores
INSERT INTO Repositorio (nombre_archivo, tipo_formato, url_ubicacion, tamanio, id_instructor, id_actividad, id_entrega) VALUES
('Guia_Proyecto_Integrador.pdf','pdf','/uploads/demo/Guia_Proyecto_Integrador.pdf',245,1,21,NULL),
('Plantilla_Modelo_ER.drawio','drawio','/uploads/demo/Plantilla_Modelo_ER.drawio',88,1,21,NULL),
('Script_Consultas_SQL.sql','sql','/uploads/demo/Script_Consultas_SQL.sql',12,1,22,NULL),
('Rubrica_Sustentacion.pdf','pdf','/uploads/demo/Rubrica_Sustentacion.pdf',180,2,24,NULL);

-- Notificaciones de ejemplo
INSERT INTO Notificacion (id_usuario, mensaje, tipo, leida) VALUES
(21,'Tienes una nueva actividad: Proyecto integrador SIRA','ACTIVIDAD',0),
(21,'Tu entrega del Taller de variables fue calificada con 4.5','CALIFICACION',0),
(1,'3 entregas pendientes por evaluar','ENTREGA',0);

-- Entregas pendientes de evaluar para el instructor 1 (flujo de calificacion)
INSERT INTO Entrega (id_actividad, id_aprendiz, fecha_entrega, estado) VALUES
(22,22,'2026-11-25 10:00:00','ENVIADO'),
(21,23,'2026-11-26 16:30:00','ENVIADO');

INSERT INTO Repositorio (nombre_archivo, tipo_formato, url_ubicacion, tamanio, id_entrega)
SELECT 'consultas_juan.zip','zip','/uploads/demo/consultas_juan.zip',34, e.id_entrega
FROM Entrega e WHERE e.id_actividad = 22 AND e.id_aprendiz = 22 LIMIT 1;

-- Los materiales heredados apuntaban a un almacenamiento externo inexistente:
-- se sirven desde los archivos demo locales para que la descarga funcione.
UPDATE Repositorio
SET url_ubicacion = CONCAT('/uploads/demo/', nombre_archivo)
WHERE id_entrega IS NULL
  AND url_ubicacion LIKE 'https://storage.sira.edu.co/materiales/%';
"""

# Insertar los datos demo justo antes de las consultas de verificacion finales
marker = "-- 1. VERIFICACION"
if marker in src:
    idx = src.index(marker)
    # retroceder al inicio de la linea del comentario
    idx = src.rfind("--", 0, idx - 1) if False else idx
    src = src[:idx] + demo.strip() + "\n\n" + src[idx:]
else:
    src = src.rstrip() + "\n" + demo

out = ROOT / "database" / "init.sql"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(src, encoding="utf-8")
print(f"OK -> {out} ({len(src)} bytes)")
