"""SIRA API + servicio del frontend compilado.

Un solo proceso sirve:
  * /api/...      -> API REST (FastAPI)
  * /uploads/...  -> archivos subidos
  * /*            -> SPA de React (frontend_sira/dist copiado a backend_sira/static)

Así el despliegue es de un único puerto y no hay problemas de CORS ni de URLs
cruzadas entre frontend y backend.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from . import models, schemas
from .config import settings
from .database import engine, get_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sira")

BASE_DIR = Path(__file__).resolve().parent.parent
UPLOAD_DIR = (BASE_DIR / settings.UPLOAD_DIR).resolve()
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="API RESTful para la gestión de actividades, entregas y retroalimentación de SIRA.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=settings.cors_origins != ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    """Crea tablas si la base está vacía; si la BD no responde, la app igual arranca."""
    try:
        models.Base.metadata.create_all(bind=engine)
        logger.info("Base de datos verificada correctamente")
    except Exception as exc:  # pragma: no cover
        logger.error("No se pudo verificar la base de datos al arrancar: %s", exc)


# ============================================================ utilidades
def hash_password(plain: str) -> str:
    return hashlib.sha256(plain.encode("utf-8")).hexdigest()


def verify_password(plain: str, stored: Optional[str]) -> bool:
    if not stored:
        return False
    stored = stored.strip()
    return hmac.compare_digest(stored, hash_password(plain)) or hmac.compare_digest(stored, plain)


def make_token(user_id: int, rol: str) -> str:
    payload = f"{user_id}|{rol}|{int(datetime.utcnow().timestamp())}"
    sig = hmac.new(settings.SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}|{sig}"


def rol_de(db: Session, id_usuario: int) -> str:
    row = db.execute(
        text(
            """
            SELECT CASE
                     WHEN i.id_instructor IS NOT NULL THEN 'INSTRUCTOR'
                     WHEN a.id_aprendiz IS NOT NULL THEN 'APRENDIZ'
                     ELSE 'USUARIO'
                   END AS rol
            FROM Usuario u
            LEFT JOIN Instructor i ON i.id_instructor = u.id_usuario
            LEFT JOIN Aprendiz a ON a.id_aprendiz = u.id_usuario
            WHERE u.id_usuario = :id
            """
        ),
        {"id": id_usuario},
    ).mappings().first()
    return row["rol"] if row else "USUARIO"


def guardar_archivo(archivo: UploadFile, subcarpeta: str = "") -> tuple[str, str, int]:
    """Guarda el archivo y devuelve (nombre_original, url_publica, tamanio_kb)."""
    if not archivo.filename:
        raise HTTPException(status_code=400, detail="El archivo no tiene nombre")
    contenido = archivo.file.read()
    limite = settings.MAX_UPLOAD_MB * 1024 * 1024
    if len(contenido) > limite:
        raise HTTPException(status_code=413, detail=f"El archivo supera {settings.MAX_UPLOAD_MB} MB")
    if not contenido:
        raise HTTPException(status_code=400, detail="El archivo está vacío")

    extension = Path(archivo.filename).suffix.lower()[:12]
    destino_dir = UPLOAD_DIR / subcarpeta if subcarpeta else UPLOAD_DIR
    destino_dir.mkdir(parents=True, exist_ok=True)
    nombre_fisico = f"{uuid.uuid4().hex}{extension}"
    destino = destino_dir / nombre_fisico
    destino.write_bytes(contenido)
    url = f"/uploads/{subcarpeta + '/' if subcarpeta else ''}{nombre_fisico}"
    tamanio_kb = max(1, round(len(contenido) / 1024))
    return archivo.filename, url, tamanio_kb


def borrar_archivo(url: str) -> None:
    if not url or not url.startswith("/uploads/"):
        return
    ruta = (UPLOAD_DIR / url[len("/uploads/") :]).resolve()
    try:
        if ruta.is_file() and UPLOAD_DIR in ruta.parents:
            ruta.unlink()
    except OSError:
        pass


# ============================================================ modelos de entrada
class LoginRequest(BaseModel):
    username: str
    password: str


# ============================================================ salud / raíz API
@app.get("/api/health", tags=["Sistema"])
def health(db: Session = Depends(get_db)):
    estado = {"status": "ok", "api": "ok", "database": "ok", "version": settings.VERSION}
    try:
        db.execute(text("SELECT 1"))
        totales = db.execute(
            text(
                "SELECT (SELECT COUNT(*) FROM Usuario) usuarios,"
                "       (SELECT COUNT(*) FROM Actividad) actividades,"
                "       (SELECT COUNT(*) FROM Entrega) entregas"
            )
        ).mappings().first()
        estado["registros"] = dict(totales) if totales else {}
    except Exception as exc:
        estado["status"] = "degradado"
        estado["database"] = f"error: {exc.__class__.__name__}"
    return estado


@app.get("/api", tags=["Sistema"])
def api_info():
    return {
        "nombre": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs": "/docs",
        "health": "/api/health",
    }


# ============================================================ autenticación
@app.post("/api/login", tags=["Autenticación"])
def login(credentials: LoginRequest, db: Session = Depends(get_db)):
    """Valida email (o número de documento) + contraseña y devuelve el rol."""
    identificador = (credentials.username or "").strip()
    if not identificador:
        raise HTTPException(status_code=400, detail="Debes indicar usuario o correo")

    usuario = db.execute(
        text(
            """
            SELECT u.id_usuario, u.nombres, u.apellidos, u.email, u.num_documento,
                   u.password AS contrasena,
                   CASE
                     WHEN i.id_instructor IS NOT NULL THEN 'INSTRUCTOR'
                     WHEN a.id_aprendiz IS NOT NULL THEN 'APRENDIZ'
                     ELSE 'USUARIO'
                   END AS rol
            FROM Usuario u
            LEFT JOIN Instructor i ON i.id_instructor = u.id_usuario
            LEFT JOIN Aprendiz a ON a.id_aprendiz = u.id_usuario
            WHERE u.email = :id OR u.num_documento = :id
            LIMIT 1
            """
        ),
        {"id": identificador},
    ).mappings().first()

    if not usuario or not verify_password(credentials.password, usuario["contrasena"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas",
        )

    return {
        "token": make_token(usuario["id_usuario"], usuario["rol"]),
        "usuario": f"{usuario['nombres']} {usuario['apellidos']}",
        "nombres": usuario["nombres"],
        "apellidos": usuario["apellidos"],
        "email": usuario["email"],
        "id_usuario": usuario["id_usuario"],
        "rol": usuario["rol"],
    }


# ============================================================ usuarios
@app.get("/api/usuarios", response_model=List[schemas.UsuarioResponse], tags=["Usuarios"])
def listar_usuarios(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT u.id_usuario, u.num_documento, u.nombres, u.apellidos, u.email, u.fecha_registro,
                   CASE WHEN i.id_instructor IS NOT NULL THEN 'INSTRUCTOR'
                        WHEN a.id_aprendiz IS NOT NULL THEN 'APRENDIZ'
                        ELSE 'USUARIO' END AS rol
            FROM Usuario u
            LEFT JOIN Instructor i ON i.id_instructor = u.id_usuario
            LEFT JOIN Aprendiz a ON a.id_aprendiz = u.id_usuario
            ORDER BY u.id_usuario
            LIMIT :limit OFFSET :skip
            """
        ),
        {"limit": limit, "skip": skip},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.post(
    "/api/usuarios",
    response_model=schemas.UsuarioResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Usuarios"],
)
def crear_usuario(usuario: schemas.UsuarioCreate, db: Session = Depends(get_db)):
    existe = db.execute(
        text("SELECT id_usuario FROM Usuario WHERE email = :email OR num_documento = :doc"),
        {"email": usuario.email, "doc": usuario.num_documento},
    ).first()
    if existe:
        raise HTTPException(status_code=400, detail="El email o documento ya está registrado")

    resultado = db.execute(
        text(
            """
            INSERT INTO Usuario (num_documento, nombres, apellidos, email, password)
            VALUES (:doc, :nombres, :apellidos, :email, :password)
            """
        ),
        {
            "doc": usuario.num_documento,
            "nombres": usuario.nombres,
            "apellidos": usuario.apellidos,
            "email": usuario.email,
            "password": hash_password(usuario.contrasena),
        },
    )
    db.commit()
    nuevo = db.execute(
        text(
            "SELECT id_usuario, num_documento, nombres, apellidos, email, fecha_registro "
            "FROM Usuario WHERE id_usuario = :id"
        ),
        {"id": resultado.lastrowid},
    ).mappings().first()
    return dict(nuevo)


@app.get("/api/usuarios/{id_usuario}", response_model=schemas.UsuarioResponse, tags=["Usuarios"])
def obtener_usuario(id_usuario: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text(
            """
            SELECT u.id_usuario, u.num_documento, u.nombres, u.apellidos, u.email, u.fecha_registro,
                   CASE WHEN i.id_instructor IS NOT NULL THEN 'INSTRUCTOR'
                        WHEN a.id_aprendiz IS NOT NULL THEN 'APRENDIZ'
                        ELSE 'USUARIO' END AS rol
            FROM Usuario u
            LEFT JOIN Instructor i ON i.id_instructor = u.id_usuario
            LEFT JOIN Aprendiz a ON a.id_aprendiz = u.id_usuario
            WHERE u.id_usuario = :id
            """
        ),
        {"id": id_usuario},
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return dict(fila)


@app.get("/api/usuarios/{id_usuario}/perfil", tags=["Usuarios"])
def obtener_perfil_usuario(id_usuario: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text(
            """
            SELECT u.id_usuario, u.num_documento, u.nombres, u.apellidos, u.email, u.fecha_registro,
                   CASE WHEN i.id_instructor IS NOT NULL THEN 'INSTRUCTOR'
                        WHEN a.id_aprendiz IS NOT NULL THEN 'APRENDIZ'
                        ELSE 'USUARIO' END AS rol,
                   i.acred_lic, i.telefono_celular AS tel_instructor,
                   a.id_ficha, f.numero_ficha, a.celular AS tel_aprendiz,
                   p.nombre_programa
            FROM Usuario u
            LEFT JOIN Instructor i ON i.id_instructor = u.id_usuario
            LEFT JOIN Aprendiz a ON a.id_aprendiz = u.id_usuario
            LEFT JOIN Ficha f ON f.id_ficha = a.id_ficha
            LEFT JOIN Programa_Formacion p ON p.id_programa = f.id_programa
            WHERE u.id_usuario = :id
            """
        ),
        {"id": id_usuario},
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return dict(fila)


@app.put("/api/usuarios/{id_usuario}/password", tags=["Usuarios"])
def cambiar_password(id_usuario: int, datos: schemas.CambioPassword, db: Session = Depends(get_db)):
    actual = db.execute(
        text("SELECT password FROM Usuario WHERE id_usuario = :id"), {"id": id_usuario}
    ).mappings().first()
    if not actual:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    if not verify_password(datos.actual, actual["password"]):
        raise HTTPException(status_code=400, detail="La contraseña actual no es correcta")
    db.execute(
        text("UPDATE Usuario SET password = :p WHERE id_usuario = :id"),
        {"p": hash_password(datos.nueva), "id": id_usuario},
    )
    db.commit()
    return {"ok": True, "mensaje": "Contraseña actualizada"}


@app.get("/api/usuarios/{id_usuario}/notificaciones-no-leidas", tags=["Usuarios"])
def notificaciones_no_leidas(id_usuario: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            "SELECT id_notificacion, mensaje, tipo, fecha_envio FROM Notificacion "
            "WHERE id_usuario = :id AND leida = FALSE ORDER BY fecha_envio DESC"
        ),
        {"id": id_usuario},
    ).mappings().all()
    return [dict(f) for f in filas]


# ============================================================ fichas
@app.get("/api/fichas", tags=["Fichas y Reportes"])
def listar_fichas(id_instructor: Optional[int] = None, db: Session = Depends(get_db)):
    sql = """
        SELECT f.id_ficha, f.numero_ficha, f.jornada, f.fecha_inicio, f.fecha_fin,
               f.id_programa, f.id_instructor, p.nombre_programa,
               CONCAT(u.nombres, ' ', u.apellidos) AS instructor_lider,
               (SELECT COUNT(*) FROM Aprendiz a WHERE a.id_ficha = f.id_ficha) AS total_aprendices
        FROM Ficha f
        JOIN Programa_Formacion p ON p.id_programa = f.id_programa
        JOIN Usuario u ON u.id_usuario = f.id_instructor
    """
    params = {}
    if id_instructor:
        sql += " WHERE f.id_instructor = :id_instructor"
        params["id_instructor"] = id_instructor
    sql += " ORDER BY f.numero_ficha"
    return [dict(f) for f in db.execute(text(sql), params).mappings().all()]


@app.get("/api/fichas/promedio-notas", tags=["Fichas y Reportes"])
def promedio_notas_fichas(db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT f.numero_ficha, ROUND(AVG(r.nota), 2) AS promedio_nota,
                   COUNT(r.id_retroalimentacion) AS total_calificaciones
            FROM Ficha f
            JOIN Aprendiz apr ON apr.id_ficha = f.id_ficha
            JOIN Entrega e ON e.id_aprendiz = apr.id_aprendiz
            JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
            GROUP BY f.id_ficha, f.numero_ficha
            ORDER BY promedio_nota DESC
            """
        )
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/fichas/resumen-programas", tags=["Fichas y Reportes"])
def resumen_fichas_programas(db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT pf.nombre_programa, f.numero_ficha, f.jornada,
                   CONCAT(ui.nombres, ' ', ui.apellidos) AS instructor_lider,
                   COUNT(apr.id_aprendiz) AS total_aprendices
            FROM Ficha f
            JOIN Programa_Formacion pf ON pf.id_programa = f.id_programa
            JOIN Instructor ins ON ins.id_instructor = f.id_instructor
            JOIN Usuario ui ON ui.id_usuario = ins.id_instructor
            LEFT JOIN Aprendiz apr ON apr.id_ficha = f.id_ficha
            GROUP BY pf.nombre_programa, f.id_ficha, f.numero_ficha, f.jornada, ui.nombres, ui.apellidos
            ORDER BY pf.nombre_programa, f.numero_ficha
            """
        )
    ).mappings().all()
    return [dict(f) for f in filas]


# ============================================================ actividades
@app.get("/api/actividades", tags=["Actividades"])
def listar_actividades(
    id_instructor: Optional[int] = None,
    id_ficha: Optional[int] = None,
    db: Session = Depends(get_db),
):
    sql = """
        SELECT a.id_actividad, a.titulo, a.descripcion, a.fecha_vencimiento, a.tipo_actividad,
               a.id_instructor, a.id_ficha, a.id_resultado,
               f.numero_ficha, p.nombre_programa,
               CONCAT(u.nombres, ' ', u.apellidos) AS instructor,
               (SELECT COUNT(*) FROM Entrega e WHERE e.id_actividad = a.id_actividad) AS total_entregas,
               (SELECT COUNT(*) FROM Aprendiz ap WHERE ap.id_ficha = a.id_ficha) AS total_aprendices
        FROM Actividad a
        JOIN Ficha f ON f.id_ficha = a.id_ficha
        JOIN Programa_Formacion p ON p.id_programa = f.id_programa
        JOIN Usuario u ON u.id_usuario = a.id_instructor
    """
    condiciones, params = [], {}
    if id_instructor:
        condiciones.append("a.id_instructor = :id_instructor")
        params["id_instructor"] = id_instructor
    if id_ficha:
        condiciones.append("a.id_ficha = :id_ficha")
        params["id_ficha"] = id_ficha
    if condiciones:
        sql += " WHERE " + " AND ".join(condiciones)
    sql += " ORDER BY a.fecha_vencimiento DESC"
    return [dict(f) for f in db.execute(text(sql), params).mappings().all()]


@app.post(
    "/api/actividades",
    response_model=schemas.ActividadResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Actividades"],
)
def crear_actividad(actividad: schemas.ActividadCreate, db: Session = Depends(get_db)):
    ficha = db.execute(
        text("SELECT id_ficha FROM Ficha WHERE id_ficha = :id"), {"id": actividad.id_ficha}
    ).first()
    if not ficha:
        raise HTTPException(status_code=404, detail="La ficha especificada no existe")
    instructor = db.execute(
        text("SELECT id_instructor FROM Instructor WHERE id_instructor = :id"),
        {"id": actividad.id_instructor},
    ).first()
    if not instructor:
        raise HTTPException(status_code=404, detail="El instructor especificado no existe")

    resultado = db.execute(
        text(
            """
            INSERT INTO Actividad (titulo, descripcion, fecha_vencimiento, tipo_actividad,
                                   id_instructor, id_ficha, id_resultado)
            VALUES (:titulo, :descripcion, :fecha, :tipo, :instructor, :ficha, :resultado)
            """
        ),
        {
            "titulo": actividad.titulo,
            "descripcion": actividad.descripcion,
            "fecha": actividad.fecha_vencimiento,
            "tipo": actividad.tipo_actividad,
            "instructor": actividad.id_instructor,
            "ficha": actividad.id_ficha,
            "resultado": actividad.id_resultado,
        },
    )
    db.commit()
    nueva = db.execute(
        text("SELECT * FROM Actividad WHERE id_actividad = :id"), {"id": resultado.lastrowid}
    ).mappings().first()
    return dict(nueva)


@app.delete("/api/actividades/{id_actividad}", tags=["Actividades"])
def eliminar_actividad(id_actividad: int, db: Session = Depends(get_db)):
    existe = db.execute(
        text("SELECT id_actividad FROM Actividad WHERE id_actividad = :id"), {"id": id_actividad}
    ).first()
    if not existe:
        raise HTTPException(status_code=404, detail="Actividad no encontrada")

    archivos = db.execute(
        text(
            """
            SELECT rep.url_ubicacion FROM Repositorio rep
            LEFT JOIN Entrega e ON e.id_entrega = rep.id_entrega
            WHERE rep.id_actividad = :id OR e.id_actividad = :id
            """
        ),
        {"id": id_actividad},
    ).mappings().all()

    db.execute(
        text(
            """
            DELETE c FROM Comentario c
            JOIN Retroalimentacion r ON r.id_retroalimentacion = c.id_retroalimentacion
            JOIN Entrega e ON e.id_entrega = r.id_entrega
            WHERE e.id_actividad = :id
            """
        ),
        {"id": id_actividad},
    )
    db.execute(
        text(
            """
            DELETE r FROM Retroalimentacion r
            JOIN Entrega e ON e.id_entrega = r.id_entrega
            WHERE e.id_actividad = :id
            """
        ),
        {"id": id_actividad},
    )
    db.execute(
        text(
            """
            DELETE rep FROM Repositorio rep
            LEFT JOIN Entrega e ON e.id_entrega = rep.id_entrega
            WHERE rep.id_actividad = :id OR e.id_actividad = :id
            """
        ),
        {"id": id_actividad},
    )
    db.execute(text("DELETE FROM Entrega WHERE id_actividad = :id"), {"id": id_actividad})
    db.execute(text("DELETE FROM Actividad WHERE id_actividad = :id"), {"id": id_actividad})
    db.commit()
    for archivo in archivos:
        borrar_archivo(archivo["url_ubicacion"])
    return {"ok": True, "mensaje": "Actividad eliminada"}


@app.get("/api/actividades/{id_actividad}/pendientes-entrega", tags=["Actividades"])
def aprendices_sin_entregar(id_actividad: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT u.nombres, u.apellidos, u.email
            FROM Aprendiz apr
            JOIN Usuario u ON u.id_usuario = apr.id_aprendiz
            LEFT JOIN Entrega e ON e.id_aprendiz = apr.id_aprendiz AND e.id_actividad = :id
            WHERE apr.id_ficha = (SELECT id_ficha FROM Actividad WHERE id_actividad = :id)
              AND e.id_entrega IS NULL
            ORDER BY u.apellidos, u.nombres
            """
        ),
        {"id": id_actividad},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/actividades/{id_actividad}/materiales", tags=["Actividades"])
def materiales_actividad(id_actividad: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT id_repositorio, nombre_archivo, tipo_formato, url_ubicacion, fecha_subida, tamanio
            FROM Repositorio
            WHERE id_actividad = :id
            ORDER BY fecha_subida DESC
            """
        ),
        {"id": id_actividad},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/aprendices/{id_aprendiz}/actividades", tags=["Actividades"])
def actividades_aprendiz(id_aprendiz: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT a.id_actividad, a.titulo, a.descripcion, a.fecha_vencimiento, a.tipo_actividad,
                   f.numero_ficha, CONCAT(u.nombres, ' ', u.apellidos) AS instructor,
                   e.id_entrega, e.estado, e.fecha_entrega,
                   r.nota, r.descripcion AS retroalimentacion, r.fecha_calificacion,
                   (SELECT rep.nombre_archivo FROM Repositorio rep
                     WHERE rep.id_entrega = e.id_entrega LIMIT 1) AS archivo_entrega,
                   (SELECT rep.url_ubicacion FROM Repositorio rep
                     WHERE rep.id_entrega = e.id_entrega LIMIT 1) AS url_entrega
            FROM Actividad a
            JOIN Ficha f ON f.id_ficha = a.id_ficha
            JOIN Usuario u ON u.id_usuario = a.id_instructor
            JOIN Aprendiz ap ON ap.id_ficha = a.id_ficha AND ap.id_aprendiz = :id
            LEFT JOIN Entrega e ON e.id_actividad = a.id_actividad AND e.id_aprendiz = :id
            LEFT JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
            ORDER BY a.fecha_vencimiento ASC
            """
        ),
        {"id": id_aprendiz},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/aprendices/{id_aprendiz}/actividades-pendientes", tags=["Actividades"])
def actividades_pendientes(id_aprendiz: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT act.id_actividad, act.titulo, act.fecha_vencimiento, act.tipo_actividad, f.numero_ficha
            FROM Actividad act
            JOIN Aprendiz apr ON apr.id_ficha = act.id_ficha
            JOIN Ficha f ON f.id_ficha = act.id_ficha
            LEFT JOIN Entrega e ON e.id_actividad = act.id_actividad AND e.id_aprendiz = apr.id_aprendiz
            WHERE apr.id_aprendiz = :id AND e.id_entrega IS NULL
            ORDER BY act.fecha_vencimiento ASC
            """
        ),
        {"id": id_aprendiz},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/instructores/{id_instructor}/actividades-avance", tags=["Actividades"])
def actividades_avance(id_instructor: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT act.id_actividad, act.titulo, act.descripcion, act.fecha_vencimiento,
                   act.tipo_actividad, f.numero_ficha, act.id_ficha,
                   COUNT(DISTINCT e.id_entrega) AS entregas_recibidas,
                   (SELECT COUNT(*) FROM Aprendiz WHERE id_ficha = f.id_ficha) AS total_aprendices
            FROM Actividad act
            JOIN Ficha f ON f.id_ficha = act.id_ficha
            LEFT JOIN Entrega e ON e.id_actividad = act.id_actividad
            WHERE act.id_instructor = :id
            GROUP BY act.id_actividad, act.titulo, act.descripcion, act.fecha_vencimiento,
                     act.tipo_actividad, f.numero_ficha, f.id_ficha
            ORDER BY act.fecha_vencimiento DESC
            """
        ),
        {"id": id_instructor},
    ).mappings().all()
    return [dict(f) for f in filas]


# ============================================================ entregas
@app.post(
    "/api/entregas",
    response_model=schemas.EntregaResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Entregas"],
)
def crear_entrega(entrega: schemas.EntregaCreate, db: Session = Depends(get_db)):
    actividad = db.execute(
        text("SELECT id_actividad, fecha_vencimiento FROM Actividad WHERE id_actividad = :id"),
        {"id": entrega.id_actividad},
    ).mappings().first()
    if not actividad:
        raise HTTPException(status_code=404, detail="La actividad no existe")
    if datetime.now() > actividad["fecha_vencimiento"]:
        raise HTTPException(status_code=400, detail="El plazo de entrega para esta actividad ha expirado")

    existente = db.execute(
        text("SELECT id_entrega FROM Entrega WHERE id_actividad = :a AND id_aprendiz = :p"),
        {"a": entrega.id_actividad, "p": entrega.id_aprendiz},
    ).first()
    if existente:
        raise HTTPException(status_code=400, detail="Ya existe una entrega para esta actividad")

    resultado = db.execute(
        text(
            "INSERT INTO Entrega (id_actividad, id_aprendiz, fecha_entrega, estado) "
            "VALUES (:a, :p, NOW(), 'ENVIADO')"
        ),
        {"a": entrega.id_actividad, "p": entrega.id_aprendiz},
    )
    db.commit()
    fila = db.execute(
        text("SELECT * FROM Entrega WHERE id_entrega = :id"), {"id": resultado.lastrowid}
    ).mappings().first()
    return dict(fila)


@app.post("/api/entregas/upload", status_code=status.HTTP_201_CREATED, tags=["Entregas"])
def subir_entrega(
    id_actividad: int = Form(...),
    id_aprendiz: int = Form(...),
    archivo: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Registra (o reemplaza) la entrega de un aprendiz con su archivo."""
    actividad = db.execute(
        text("SELECT id_actividad, fecha_vencimiento, titulo FROM Actividad WHERE id_actividad = :id"),
        {"id": id_actividad},
    ).mappings().first()
    if not actividad:
        raise HTTPException(status_code=404, detail="La actividad no existe")
    if datetime.now() > actividad["fecha_vencimiento"]:
        raise HTTPException(status_code=400, detail="El plazo de entrega para esta actividad ha expirado")

    aprendiz = db.execute(
        text("SELECT id_aprendiz FROM Aprendiz WHERE id_aprendiz = :id"), {"id": id_aprendiz}
    ).first()
    if not aprendiz:
        raise HTTPException(status_code=404, detail="El aprendiz no existe")

    nombre_original, url, tamanio_kb = guardar_archivo(archivo, "entregas")

    existente = db.execute(
        text("SELECT id_entrega FROM Entrega WHERE id_actividad = :a AND id_aprendiz = :p"),
        {"a": id_actividad, "p": id_aprendiz},
    ).mappings().first()

    if existente:
        id_entrega = existente["id_entrega"]
        db.execute(
            text("UPDATE Entrega SET fecha_entrega = NOW(), estado = 'ENVIADO' WHERE id_entrega = :id"),
            {"id": id_entrega},
        )
        anterior = db.execute(
            text("SELECT id_repositorio, url_ubicacion FROM Repositorio WHERE id_entrega = :id"),
            {"id": id_entrega},
        ).mappings().first()
        if anterior:
            borrar_archivo(anterior["url_ubicacion"])
            db.execute(
                text(
                    "UPDATE Repositorio SET nombre_archivo = :n, tipo_formato = :t, "
                    "url_ubicacion = :u, tamanio = :s, fecha_subida = NOW() WHERE id_repositorio = :r"
                ),
                {
                    "n": nombre_original,
                    "t": Path(nombre_original).suffix.lstrip(".").lower() or "bin",
                    "u": url,
                    "s": tamanio_kb,
                    "r": anterior["id_repositorio"],
                },
            )
        else:
            db.execute(
                text(
                    "INSERT INTO Repositorio (nombre_archivo, tipo_formato, url_ubicacion, tamanio, id_entrega) "
                    "VALUES (:n, :t, :u, :s, :e)"
                ),
                {
                    "n": nombre_original,
                    "t": Path(nombre_original).suffix.lstrip(".").lower() or "bin",
                    "u": url,
                    "s": tamanio_kb,
                    "e": id_entrega,
                },
            )
    else:
        resultado = db.execute(
            text(
                "INSERT INTO Entrega (id_actividad, id_aprendiz, fecha_entrega, estado) "
                "VALUES (:a, :p, NOW(), 'ENVIADO')"
            ),
            {"a": id_actividad, "p": id_aprendiz},
        )
        id_entrega = resultado.lastrowid
        db.execute(
            text(
                "INSERT INTO Repositorio (nombre_archivo, tipo_formato, url_ubicacion, tamanio, id_entrega) "
                "VALUES (:n, :t, :u, :s, :e)"
            ),
            {
                "n": nombre_original,
                "t": Path(nombre_original).suffix.lstrip(".").lower() or "bin",
                "u": url,
                "s": tamanio_kb,
                "e": id_entrega,
            },
        )

    db.execute(
        text(
            "INSERT INTO Notificacion (id_usuario, mensaje, tipo) VALUES (:u, :m, 'ENTREGA')"
        ),
        {
            "u": id_aprendiz,
            "m": f"Entrega registrada para la actividad: {actividad['titulo']}",
        },
    )
    db.commit()

    fila = db.execute(
        text("SELECT * FROM Entrega WHERE id_entrega = :id"), {"id": id_entrega}
    ).mappings().first()
    return {**dict(fila), "archivo": nombre_original, "url_archivo": url}


@app.get("/api/entregas/{id_entrega}", response_model=schemas.EntregaResponse, tags=["Entregas"])
def obtener_entrega(id_entrega: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text("SELECT * FROM Entrega WHERE id_entrega = :id"), {"id": id_entrega}
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Entrega no encontrada")
    return dict(fila)


@app.get("/api/entregas/{id_entrega}/detalle", tags=["Entregas"])
def detalle_entrega(id_entrega: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text(
            """
            SELECT e.id_entrega, e.id_actividad, e.id_aprendiz, e.fecha_entrega, e.estado,
                   act.titulo, r.nota, r.descripcion, r.fecha_calificacion,
                   rep.nombre_archivo, rep.url_ubicacion
            FROM Entrega e
            JOIN Actividad act ON act.id_actividad = e.id_actividad
            LEFT JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
            LEFT JOIN Repositorio rep ON rep.id_entrega = e.id_entrega
            WHERE e.id_entrega = :id
            """
        ),
        {"id": id_entrega},
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Entrega no encontrada")
    return dict(fila)


@app.get("/api/aprendices/{id_aprendiz}/historial-entregas", tags=["Entregas"])
def historial_entregas(id_aprendiz: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT e.id_entrega, act.id_actividad, act.titulo, act.tipo_actividad,
                   e.fecha_entrega, e.estado, r.nota, r.descripcion AS retro_descripcion,
                   r.fecha_calificacion,
                   (SELECT rep.nombre_archivo FROM Repositorio rep
                     WHERE rep.id_entrega = e.id_entrega LIMIT 1) AS archivo
            FROM Entrega e
            JOIN Actividad act ON act.id_actividad = e.id_actividad
            LEFT JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
            WHERE e.id_aprendiz = :id
            ORDER BY e.fecha_entrega DESC
            """
        ),
        {"id": id_aprendiz},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.get("/api/instructores/{id_instructor}/entregas-pendientes", tags=["Entregas"])
def entregas_pendientes_evaluar(id_instructor: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT e.id_entrega, e.id_actividad, e.id_aprendiz, e.fecha_entrega, e.estado,
                   u.nombres, u.apellidos, act.titulo, act.tipo_actividad,
                   (SELECT rep.nombre_archivo FROM Repositorio rep
                     WHERE rep.id_entrega = e.id_entrega LIMIT 1) AS archivo
            FROM Entrega e
            JOIN Actividad act ON act.id_actividad = e.id_actividad
            JOIN Aprendiz apr ON apr.id_aprendiz = e.id_aprendiz
            JOIN Usuario u ON u.id_usuario = apr.id_aprendiz
            WHERE act.id_instructor = :id AND e.estado IN ('ENVIADO', 'CORREGIR')
            ORDER BY e.fecha_entrega ASC
            """
        ),
        {"id": id_instructor},
    ).mappings().all()
    return [dict(f) for f in filas]


# ============================================================ retroalimentación
@app.post(
    "/api/retroalimentaciones",
    response_model=schemas.RetroalimentacionResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Retroalimentación"],
)
def calificar_entrega(retro: schemas.RetroalimentacionCreate, db: Session = Depends(get_db)):
    entrega = db.execute(
        text("SELECT id_entrega, id_aprendiz FROM Entrega WHERE id_entrega = :id"),
        {"id": retro.id_entrega},
    ).mappings().first()
    if not entrega:
        raise HTTPException(status_code=404, detail="Entrega no encontrada")

    existente = db.execute(
        text("SELECT id_retroalimentacion FROM Retroalimentacion WHERE id_entrega = :id"),
        {"id": retro.id_entrega},
    ).first()
    if existente:
        db.execute(
            text(
                "UPDATE Retroalimentacion SET nota = :n, descripcion = :d, "
                "id_instructor = :i, fecha_calificacion = NOW() WHERE id_entrega = :e"
            ),
            {
                "n": retro.nota,
                "d": retro.descripcion,
                "i": retro.id_instructor,
                "e": retro.id_entrega,
            },
        )
        id_retro = existente[0]
    else:
        resultado = db.execute(
            text(
                "INSERT INTO Retroalimentacion (id_entrega, id_instructor, nota, descripcion, fecha_calificacion) "
                "VALUES (:e, :i, :n, :d, NOW())"
            ),
            {
                "e": retro.id_entrega,
                "i": retro.id_instructor,
                "n": retro.nota,
                "d": retro.descripcion,
            },
        )
        id_retro = resultado.lastrowid

    db.execute(
        text("UPDATE Entrega SET estado = 'EVALUADO' WHERE id_entrega = :id"),
        {"id": retro.id_entrega},
    )
    db.execute(
        text("INSERT INTO Notificacion (id_usuario, mensaje, tipo) VALUES (:u, :m, 'CALIFICACION')"),
        {
            "u": entrega["id_aprendiz"],
            "m": f"Tu entrega fue calificada con {retro.nota}",
        },
    )
    db.commit()

    fila = db.execute(
        text("SELECT * FROM Retroalimentacion WHERE id_retroalimentacion = :id"), {"id": id_retro}
    ).mappings().first()
    return dict(fila)


@app.get("/api/retroalimentaciones/{id_retro}/comentarios", tags=["Retroalimentación"])
def comentarios_retroalimentacion(id_retro: int, db: Session = Depends(get_db)):
    filas = db.execute(
        text(
            """
            SELECT c.id_comentario, u.nombres, u.apellidos, c.texto_comentario, c.fecha_comentario
            FROM Comentario c
            JOIN Usuario u ON u.id_usuario = c.id_usuario
            WHERE c.id_retroalimentacion = :id
            ORDER BY c.fecha_comentario ASC
            """
        ),
        {"id": id_retro},
    ).mappings().all()
    return [dict(f) for f in filas]


@app.post(
    "/api/retroalimentaciones/{id_retro}/comentarios",
    response_model=schemas.ComentarioResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Retroalimentación"],
)
def crear_comentario(id_retro: int, datos: schemas.ComentarioCreate, db: Session = Depends(get_db)):
    existe = db.execute(
        text("SELECT id_retroalimentacion FROM Retroalimentacion WHERE id_retroalimentacion = :id"),
        {"id": id_retro},
    ).first()
    if not existe:
        raise HTTPException(status_code=404, detail="Retroalimentación no encontrada")
    resultado = db.execute(
        text(
            "INSERT INTO Comentario (id_retroalimentacion, id_usuario, texto_comentario, fecha_comentario) "
            "VALUES (:r, :u, :t, NOW())"
        ),
        {"r": id_retro, "u": datos.id_usuario, "t": datos.texto_comentario},
    )
    db.commit()
    fila = db.execute(
        text("SELECT * FROM Comentario WHERE id_comentario = :id"), {"id": resultado.lastrowid}
    ).mappings().first()
    return dict(fila)


# ============================================================ materiales
@app.get("/api/materiales", tags=["Materiales"])
def listar_materiales(
    id_actividad: Optional[int] = None,
    id_instructor: Optional[int] = None,
    db: Session = Depends(get_db),
):
    sql = """
        SELECT rep.id_repositorio, rep.nombre_archivo, rep.tipo_formato, rep.url_ubicacion,
               rep.fecha_subida, rep.tamanio, rep.id_actividad, rep.id_instructor, rep.id_entrega,
               a.titulo AS actividad, f.numero_ficha,
               CONCAT(u.nombres, ' ', u.apellidos) AS instructor
        FROM Repositorio rep
        LEFT JOIN Actividad a ON a.id_actividad = rep.id_actividad
        LEFT JOIN Ficha f ON f.id_ficha = a.id_ficha
        LEFT JOIN Usuario u ON u.id_usuario = rep.id_instructor
        WHERE rep.id_entrega IS NULL
    """
    params = {}
    if id_actividad:
        sql += " AND rep.id_actividad = :id_actividad"
        params["id_actividad"] = id_actividad
    if id_instructor:
        sql += " AND rep.id_instructor = :id_instructor"
        params["id_instructor"] = id_instructor
    sql += " ORDER BY rep.fecha_subida DESC"
    return [dict(f) for f in db.execute(text(sql), params).mappings().all()]


@app.post("/api/materiales/upload", status_code=status.HTTP_201_CREATED, tags=["Materiales"])
def subir_material(
    id_actividad: int = Form(...),
    id_instructor: int = Form(...),
    archivo: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    actividad = db.execute(
        text("SELECT id_actividad, titulo FROM Actividad WHERE id_actividad = :id"),
        {"id": id_actividad},
    ).mappings().first()
    if not actividad:
        raise HTTPException(status_code=404, detail="La actividad no existe")
    instructor = db.execute(
        text("SELECT id_instructor FROM Instructor WHERE id_instructor = :id"), {"id": id_instructor}
    ).first()
    if not instructor:
        raise HTTPException(status_code=404, detail="El instructor no existe")

    nombre_original, url, tamanio_kb = guardar_archivo(archivo, "materiales")
    resultado = db.execute(
        text(
            "INSERT INTO Repositorio (nombre_archivo, tipo_formato, url_ubicacion, tamanio, "
            "id_instructor, id_actividad) VALUES (:n, :t, :u, :s, :i, :a)"
        ),
        {
            "n": nombre_original,
            "t": Path(nombre_original).suffix.lstrip(".").lower() or "bin",
            "u": url,
            "s": tamanio_kb,
            "i": id_instructor,
            "a": id_actividad,
        },
    )
    db.commit()
    fila = db.execute(
        text("SELECT * FROM Repositorio WHERE id_repositorio = :id"), {"id": resultado.lastrowid}
    ).mappings().first()
    return dict(fila)


@app.get("/api/materiales/{id_repositorio}/descargar", tags=["Materiales"])
def descargar_material(id_repositorio: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text("SELECT nombre_archivo, url_ubicacion FROM Repositorio WHERE id_repositorio = :id"),
        {"id": id_repositorio},
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Material no encontrado")
    url = fila["url_ubicacion"] or ""
    if not url.startswith("/uploads/"):
        return JSONResponse({"url": url, "nombre_archivo": fila["nombre_archivo"]})
    ruta = (UPLOAD_DIR / url[len("/uploads/") :]).resolve()
    if not ruta.is_file():
        raise HTTPException(status_code=404, detail="El archivo no está disponible en el servidor")
    return FileResponse(ruta, filename=fila["nombre_archivo"])


@app.delete("/api/materiales/{id_repositorio}", tags=["Materiales"])
def eliminar_material(id_repositorio: int, db: Session = Depends(get_db)):
    fila = db.execute(
        text("SELECT url_ubicacion FROM Repositorio WHERE id_repositorio = :id"),
        {"id": id_repositorio},
    ).mappings().first()
    if not fila:
        raise HTTPException(status_code=404, detail="Material no encontrado")
    db.execute(text("DELETE FROM Repositorio WHERE id_repositorio = :id"), {"id": id_repositorio})
    db.commit()
    borrar_archivo(fila["url_ubicacion"])
    return {"ok": True, "mensaje": "Material eliminado"}


# ============================================================ reportes
@app.get("/api/reportes/aprendiz/{id_aprendiz}", tags=["Fichas y Reportes"])
def reporte_aprendiz(id_aprendiz: int, db: Session = Depends(get_db)):
    resumen = db.execute(
        text(
            """
            SELECT COUNT(e.id_entrega) AS total_entregas,
                   COALESCE(SUM(CASE WHEN e.estado = 'EVALUADO' THEN 1 ELSE 0 END), 0) AS evaluadas,
                   COALESCE(SUM(CASE WHEN e.estado IN ('ENVIADO', 'CORREGIR') THEN 1 ELSE 0 END), 0) AS pendientes,
                   ROUND(AVG(r.nota), 2) AS promedio,
                   MAX(r.nota) AS nota_maxima,
                   MIN(r.nota) AS nota_minima
            FROM Aprendiz a
            LEFT JOIN Entrega e ON e.id_aprendiz = a.id_aprendiz
            LEFT JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
            WHERE a.id_aprendiz = :id
            """
        ),
        {"id": id_aprendiz},
    ).mappings().first()
    return dict(resumen) if resumen else {}


# ============================================================ archivos y SPA
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

if (STATIC_DIR / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")


@app.get("/{full_path:path}", include_in_schema=False)
def servir_spa(full_path: str):
    if full_path.startswith("api"):
        raise HTTPException(status_code=404, detail="Endpoint no encontrado")
    index = STATIC_DIR / "index.html"
    if not index.is_file():
        return JSONResponse(
            status_code=503,
            content={
                "detail": "Frontend no compilado. Ejecuta `npm run build` en frontend_sira "
                "o usa el Dockerfile de producción."
            },
        )
    candidato = (STATIC_DIR / full_path).resolve()
    if full_path and candidato.is_file() and STATIC_DIR in candidato.parents:
        return FileResponse(candidato)
    return FileResponse(index)
