"""Configuración central del backend SIRA.

Todos los valores tienen un default razonable para que la app pueda arrancar
sin un archivo .env (útil en Docker, CI o despliegues gestionados).
"""
from urllib.parse import quote_plus

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Base de datos
    DB_HOST: str = "127.0.0.1"
    DB_PORT: int = 3306
    DB_USER: str = "sira"
    DB_PASSWORD: str = "sira"
    DB_NAME: str = "sira"
    # Permite pegar directamente una cadena de conexión completa
    DATABASE_URL: str | None = None

    # App
    PROJECT_NAME: str = "SIRA - Backend API"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    SECRET_KEY: str = "cambia-esta-clave-en-produccion"

    # CORS: "*" o lista separada por comas
    CORS_ORIGINS: str = "*"

    # Carpeta de archivos subidos (relativa a backend_sira/)
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_MB: int = 20

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def sqlalchemy_url(self) -> str:
        if self.DATABASE_URL:
            url = self.DATABASE_URL.strip()
            if url.startswith("mysql://"):
                url = "mysql+pymysql://" + url[len("mysql://") :]
            return url
        return (
            f"mysql+pymysql://{quote_plus(self.DB_USER)}:{quote_plus(self.DB_PASSWORD)}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}?charset=utf8mb4"
        )

    @property
    def cors_origins(self) -> list[str]:
        if self.CORS_ORIGINS.strip() == "*":
            return ["*"]
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
