"""Esquemas Pydantic de entrada/salida de la API SIRA."""
from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field


# ---------------------------------------------------------------- Usuario
class UsuarioBase(BaseModel):
    num_documento: str = Field(..., max_length=20)
    nombres: str = Field(..., max_length=100)
    apellidos: str = Field(..., max_length=100)
    email: EmailStr


class UsuarioCreate(UsuarioBase):
    contrasena: str = Field(..., min_length=4, max_length=100)


class UsuarioResponse(UsuarioBase):
    model_config = ConfigDict(from_attributes=True)

    id_usuario: int
    fecha_registro: Optional[datetime] = None
    rol: Optional[str] = None


class CambioPassword(BaseModel):
    actual: str
    nueva: str = Field(..., min_length=4, max_length=100)


# ---------------------------------------------------------------- Ficha
class FichaBase(BaseModel):
    numero_ficha: str = Field(..., max_length=20)
    jornada: str = Field(..., max_length=30)
    fecha_inicio: Optional[date] = None
    fecha_fin: Optional[date] = None
    id_programa: int
    id_instructor: int


class FichaCreate(FichaBase):
    pass


class FichaResponse(FichaBase):
    model_config = ConfigDict(from_attributes=True)

    id_ficha: int


# ---------------------------------------------------------------- Actividad
class ActividadBase(BaseModel):
    titulo: str = Field(..., max_length=150)
    descripcion: Optional[str] = None
    fecha_vencimiento: datetime
    tipo_actividad: Optional[str] = Field(default=None, max_length=50)
    id_instructor: int
    id_ficha: int
    id_resultado: Optional[int] = None


class ActividadCreate(ActividadBase):
    pass


class ActividadResponse(ActividadBase):
    model_config = ConfigDict(from_attributes=True)

    id_actividad: int


# ---------------------------------------------------------------- Entrega
class EntregaBase(BaseModel):
    id_actividad: int
    id_aprendiz: int


class EntregaCreate(EntregaBase):
    pass


class EntregaResponse(EntregaBase):
    model_config = ConfigDict(from_attributes=True)

    id_entrega: int
    fecha_entrega: Optional[datetime] = None
    estado: str


# ---------------------------------------------------------------- Retroalimentación
class RetroalimentacionCreate(BaseModel):
    id_entrega: int
    id_instructor: int
    nota: float = Field(..., ge=0.0, le=5.0)
    descripcion: Optional[str] = None


class RetroalimentacionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id_retroalimentacion: int
    id_entrega: int
    id_instructor: int
    nota: float
    descripcion: Optional[str] = None
    fecha_calificacion: Optional[datetime] = None


class ComentarioCreate(BaseModel):
    id_usuario: int
    texto_comentario: str = Field(..., min_length=1)


class ComentarioResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id_comentario: int
    id_retroalimentacion: int
    id_usuario: int
    texto_comentario: str
    fecha_comentario: Optional[datetime] = None
