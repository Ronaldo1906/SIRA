-- Consultas de ejemplo SIRA
SELECT f.numero_ficha, ROUND(AVG(r.nota),2) AS promedio
FROM Ficha f
JOIN Aprendiz a ON a.id_ficha = f.id_ficha
JOIN Entrega e ON e.id_aprendiz = a.id_aprendiz
JOIN Retroalimentacion r ON r.id_entrega = e.id_entrega
GROUP BY f.id_ficha, f.numero_ficha;
