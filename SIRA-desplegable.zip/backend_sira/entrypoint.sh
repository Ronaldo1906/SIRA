#!/bin/sh
# Prepara el volumen de subidas y siembra los archivos demo la primera vez.
set -e

mkdir -p /app/uploads/entregas /app/uploads/materiales /app/uploads/demo

if [ -d /app/seed/demo ]; then
  for f in /app/seed/demo/*; do
    [ -e "$f" ] || continue
    name=$(basename "$f")
    [ -e "/app/uploads/demo/$name" ] || cp "$f" "/app/uploads/demo/$name"
  done
fi

exec "$@"
